import Pusher from "pusher";

let pusherInstance: Pusher | null = null;

export function getPusher(): Pusher | null {
  if (!process.env["PUSHER_APP_ID"]) {
    return null;
  }

  if (!pusherInstance) {
    pusherInstance = new Pusher({
      appId: process.env["PUSHER_APP_ID"] ?? "",
      key: process.env["PUSHER_KEY"] ?? "",
      secret: process.env["PUSHER_SECRET"] ?? "",
      cluster: process.env["PUSHER_CLUSTER"] ?? "us2",
      useTLS: true,
    });
  }

  return pusherInstance;
}

export async function triggerEvent(channel: string, event: string, data: unknown): Promise<void> {
  const pusher = getPusher();
  if (!pusher) return;
  try {
    await pusher.trigger(channel, event, data);
  } catch {
    // Non-critical: silently fail if Pusher is not configured
  }
}

export async function sendNotificationToUser(userId: number, notification: unknown): Promise<void> {
  await triggerEvent(`private-user-${userId}`, "notification", notification);
}

export async function sendMessageToConversation(conversationId: number, message: unknown): Promise<void> {
  await triggerEvent(`private-conversation-${conversationId}`, "new-message", message);
}
