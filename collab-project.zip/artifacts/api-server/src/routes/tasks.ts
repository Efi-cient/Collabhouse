import { Router } from "express";
import { db } from "@workspace/db";
import {
  tasksTable,
  taskAssigneesTable,
  subTasksTable,
  commentsTable,
  fileAttachmentsTable,
  activityLogsTable,
  usersTable,
  notificationsTable,
} from "@workspace/db";
import { eq, and, inArray, count } from "drizzle-orm";
import { requireAuth, requireRole, type AuthenticatedRequest } from "../lib/auth.js";
import { sendNotificationToUser } from "../lib/pusher.js";
import { z } from "zod";

const router = Router();

router.use(requireAuth);

async function getTaskWithDetails(taskId: number) {
  const [task] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, taskId))
    .limit(1);

  if (!task) return null;

  const assignees = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
      avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .innerJoin(taskAssigneesTable, eq(taskAssigneesTable.userId, usersTable.id))
    .where(eq(taskAssigneesTable.taskId, taskId));

  const subtasks = await db
    .select()
    .from(subTasksTable)
    .where(eq(subTasksTable.taskId, taskId));

  const [commentCountResult] = await db
    .select({ count: count() })
    .from(commentsTable)
    .where(eq(commentsTable.taskId, taskId));

  const [fileCountResult] = await db
    .select({ count: count() })
    .from(fileAttachmentsTable)
    .where(eq(fileAttachmentsTable.taskId, taskId));

  return {
    ...task,
    assignees,
    subtasks,
    commentCount: Number(commentCountResult?.count ?? 0),
    fileCount: Number(fileCountResult?.count ?? 0),
  };
}

async function logActivity(taskId: number, userId: number, eventType: string, metadata: Record<string, unknown> = {}) {
  await db.insert(activityLogsTable).values({ taskId, userId, eventType, metadata });
}

router.get("/", async (req: AuthenticatedRequest, res) => {
  const { projectId, assigneeId, status, priority } = req.query as Record<string, string | undefined>;

  let taskIds: number[] | null = null;

  if (assigneeId) {
    const assigned = await db
      .select({ taskId: taskAssigneesTable.taskId })
      .from(taskAssigneesTable)
      .where(eq(taskAssigneesTable.userId, parseInt(assigneeId)));
    taskIds = assigned.map(a => a.taskId);
    if (taskIds.length === 0) {
      res.json([]);
      return;
    }
  }

  let query = db.select().from(tasksTable);

  const conditions = [];
  if (projectId) conditions.push(eq(tasksTable.projectId, parseInt(projectId)));
  if (status) conditions.push(eq(tasksTable.status, status as "TODO" | "IN_PROGRESS" | "IN_REVIEW" | "DONE"));
  if (priority) conditions.push(eq(tasksTable.priority, priority as "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"));
  if (taskIds !== null) conditions.push(inArray(tasksTable.id, taskIds));

  const tasks = await (conditions.length > 0 ? query.where(and(...conditions)) : query);

  const results = await Promise.all(tasks.map(t => getTaskWithDetails(t.id)));
  res.json(results.filter(Boolean));
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const task = await getTaskWithDetails(id);
  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  res.json(task);
});

const createTaskSchema = z.object({
  projectId: z.number().int(),
  title: z.string().min(1),
  description: z.string().optional(),
  status: z.enum(["TODO", "IN_PROGRESS", "IN_REVIEW", "DONE"]).default("TODO"),
  priority: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]).default("MEDIUM"),
  dueDate: z.string().datetime().optional(),
  estimatedHours: z.number().optional(),
  parentTaskId: z.number().int().optional(),
  assigneeIds: z.array(z.number()).optional(),
});

router.post("/", async (req: AuthenticatedRequest, res) => {
  const parsed = createTaskSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.errors[0]?.message ?? "Invalid request" });
    return;
  }

  const { assigneeIds, ...taskData } = parsed.data;

  const [task] = await db
    .insert(tasksTable)
    .values({
      ...taskData,
      dueDate: taskData.dueDate ? new Date(taskData.dueDate) : null,
      createdById: req.user!.id,
    })
    .returning();

  if (!task) {
    res.status(500).json({ error: "Failed to create task" });
    return;
  }

  if (assigneeIds && assigneeIds.length > 0) {
    await db.insert(taskAssigneesTable).values(
      assigneeIds.map(uid => ({ taskId: task.id, userId: uid }))
    );

    // Send notifications to assignees
    for (const uid of assigneeIds) {
      if (uid !== req.user!.id) {
        const [notif] = await db.insert(notificationsTable).values({
          userId: uid,
          type: "TASK_ASSIGNED",
          title: "Task Assigned",
          body: `You have been assigned to "${task.title}"`,
          resourceId: task.id,
          resourceType: "task",
        }).returning();

        if (notif) {
          await sendNotificationToUser(uid, notif);
        }
      }
    }
  }

  await logActivity(task.id, req.user!.id, "TASK_CREATED", { title: task.title });

  const result = await getTaskWithDetails(task.id);
  res.status(201).json(result);
});

const updateTaskSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  status: z.enum(["TODO", "IN_PROGRESS", "IN_REVIEW", "DONE"]).optional(),
  priority: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]).optional(),
  dueDate: z.string().datetime().optional().nullable(),
  estimatedHours: z.number().optional(),
  assigneeIds: z.array(z.number()).optional(),
});

router.patch("/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const parsed = updateTaskSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const { assigneeIds, ...taskData } = parsed.data;

  const updateData: Record<string, unknown> = { ...taskData };
  if (taskData.dueDate !== undefined) {
    updateData["dueDate"] = taskData.dueDate ? new Date(taskData.dueDate) : null;
  }

  if (Object.keys(updateData).length > 0) {
    await db.update(tasksTable).set(updateData).where(eq(tasksTable.id, id));
  }

  if (assigneeIds !== undefined) {
    await db.delete(taskAssigneesTable).where(eq(taskAssigneesTable.taskId, id));
    if (assigneeIds.length > 0) {
      await db.insert(taskAssigneesTable).values(
        assigneeIds.map(uid => ({ taskId: id, userId: uid }))
      );
    }
  }

  if (taskData.status) {
    await logActivity(id, req.user!.id, "STATUS_CHANGED", { status: taskData.status });
  }

  const result = await getTaskWithDetails(id);
  if (!result) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  res.json(result);
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  await db.delete(tasksTable).where(eq(tasksTable.id, id));
  res.json({ success: true, message: "Task deleted" });
});

// Subtasks
router.get("/:id/subtasks", async (req, res) => {
  const taskId = parseInt(req.params["id"] ?? "0");
  const subtasks = await db
    .select()
    .from(subTasksTable)
    .where(eq(subTasksTable.taskId, taskId));
  res.json(subtasks);
});

router.post("/:id/subtasks", async (req, res) => {
  const taskId = parseInt(req.params["id"] ?? "0");
  const { title } = req.body as { title: string };
  if (!title) {
    res.status(400).json({ error: "Title required" });
    return;
  }

  const [subtask] = await db
    .insert(subTasksTable)
    .values({ taskId, title })
    .returning();

  res.status(201).json(subtask);
});

// Comments
router.get("/:id/comments", async (req, res) => {
  const taskId = parseInt(req.params["id"] ?? "0");

  const comments = await db
    .select({
      id: commentsTable.id,
      taskId: commentsTable.taskId,
      userId: commentsTable.userId,
      content: commentsTable.content,
      parentId: commentsTable.parentId,
      createdAt: commentsTable.createdAt,
      updatedAt: commentsTable.updatedAt,
      author: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        avatarUrl: usersTable.avatarUrl,
        createdAt: usersTable.createdAt,
        lastSeenAt: usersTable.lastSeenAt,
      },
    })
    .from(commentsTable)
    .innerJoin(usersTable, eq(usersTable.id, commentsTable.userId))
    .where(eq(commentsTable.taskId, taskId))
    .orderBy(commentsTable.createdAt);

  // Build threaded structure
  const topLevel = comments.filter(c => !c.parentId);
  const withReplies = topLevel.map(c => ({
    ...c,
    replies: comments.filter(r => r.parentId === c.id),
  }));

  res.json(withReplies);
});

router.post("/:id/comments", async (req: AuthenticatedRequest, res) => {
  const taskId = parseInt(req.params["id"] ?? "0");
  const { content, parentId } = req.body as { content: string; parentId?: number };
  if (!content) {
    res.status(400).json({ error: "Content required" });
    return;
  }

  const [comment] = await db
    .insert(commentsTable)
    .values({ taskId, userId: req.user!.id, content, parentId: parentId ?? null })
    .returning();

  if (!comment) {
    res.status(500).json({ error: "Failed to create comment" });
    return;
  }

  await logActivity(taskId, req.user!.id, "COMMENT_ADDED", { commentId: comment.id });

  const [author] = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
      avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .where(eq(usersTable.id, req.user!.id))
    .limit(1);

  res.status(201).json({ ...comment, author, replies: [] });
});

// Files
router.get("/:id/files", async (req, res) => {
  const taskId = parseInt(req.params["id"] ?? "0");

  const files = await db
    .select({
      id: fileAttachmentsTable.id,
      taskId: fileAttachmentsTable.taskId,
      uploadedById: fileAttachmentsTable.uploadedById,
      fileName: fileAttachmentsTable.fileName,
      fileUrl: fileAttachmentsTable.fileUrl,
      fileType: fileAttachmentsTable.fileType,
      fileSize: fileAttachmentsTable.fileSize,
      createdAt: fileAttachmentsTable.createdAt,
      uploader: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        avatarUrl: usersTable.avatarUrl,
        createdAt: usersTable.createdAt,
        lastSeenAt: usersTable.lastSeenAt,
      },
    })
    .from(fileAttachmentsTable)
    .innerJoin(usersTable, eq(usersTable.id, fileAttachmentsTable.uploadedById))
    .where(eq(fileAttachmentsTable.taskId, taskId))
    .orderBy(fileAttachmentsTable.createdAt);

  res.json(files);
});

router.post("/:id/files", async (req: AuthenticatedRequest, res) => {
  const taskId = parseInt(req.params["id"] ?? "0");
  const { fileName, fileUrl, fileType, fileSize } = req.body as {
    fileName: string;
    fileUrl: string;
    fileType: string;
    fileSize: number;
  };

  if (!fileName || !fileUrl || !fileType || !fileSize) {
    res.status(400).json({ error: "Missing required fields" });
    return;
  }

  const [file] = await db
    .insert(fileAttachmentsTable)
    .values({ taskId, uploadedById: req.user!.id, fileName, fileUrl, fileType, fileSize })
    .returning();

  if (!file) {
    res.status(500).json({ error: "Failed to attach file" });
    return;
  }

  await logActivity(taskId, req.user!.id, "FILE_UPLOADED", { fileName });

  const [uploader] = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
      avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .where(eq(usersTable.id, req.user!.id))
    .limit(1);

  res.status(201).json({ ...file, uploader });
});

// Activity
router.get("/:id/activity", async (req, res) => {
  const taskId = parseInt(req.params["id"] ?? "0");

  const logs = await db
    .select({
      id: activityLogsTable.id,
      taskId: activityLogsTable.taskId,
      userId: activityLogsTable.userId,
      eventType: activityLogsTable.eventType,
      metadata: activityLogsTable.metadata,
      createdAt: activityLogsTable.createdAt,
      user: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        avatarUrl: usersTable.avatarUrl,
        createdAt: usersTable.createdAt,
        lastSeenAt: usersTable.lastSeenAt,
      },
    })
    .from(activityLogsTable)
    .innerJoin(usersTable, eq(usersTable.id, activityLogsTable.userId))
    .where(eq(activityLogsTable.taskId, taskId))
    .orderBy(activityLogsTable.createdAt);

  res.json(logs);
});

export default router;
