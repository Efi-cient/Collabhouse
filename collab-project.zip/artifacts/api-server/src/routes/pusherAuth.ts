import { Router } from "express";
import { getPusher } from "../lib/pusher.js";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth.js";

const router = Router();

router.use(requireAuth);

router.post("/", async (req: AuthenticatedRequest, res) => {
  const { socket_id, channel_name } = req.body as { socket_id: string; channel_name: string };

  if (!socket_id || !channel_name) {
    res.status(400).json({ error: "socket_id and channel_name are required" });
    return;
  }

  const pusher = getPusher();
  if (!pusher) {
    res.status(503).json({ error: "Pusher not configured" });
    return;
  }

  // Verify user can access the channel
  const userId = req.user!.id;

  // User can access their own private channel or conversations they're in
  if (channel_name === `private-user-${userId}`) {
    const authResponse = pusher.authorizeChannel(socket_id, channel_name);
    res.json(authResponse);
    return;
  }

  if (channel_name.startsWith("private-conversation-")) {
    const convId = parseInt(channel_name.replace("private-conversation-", ""));
    if (!isNaN(convId)) {
      const authResponse = pusher.authorizeChannel(socket_id, channel_name);
      res.json(authResponse);
      return;
    }
  }

  if (channel_name.startsWith("presence-")) {
    const authResponse = pusher.authorizeChannel(socket_id, channel_name, {
      user_id: String(userId),
      user_info: { name: req.user!.name },
    });
    res.json(authResponse);
    return;
  }

  res.status(403).json({ error: "Forbidden" });
});

export default router;
