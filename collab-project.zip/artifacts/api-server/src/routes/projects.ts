import { Router } from "express";
import { db } from "@workspace/db";
import {
  projectsTable,
  projectMembersTable,
  usersTable,
  milestonesTable,
  tasksTable,
} from "@workspace/db";
import { eq, inArray, count, and, lt, sql } from "drizzle-orm";
import { requireAuth, requireRole, type AuthenticatedRequest } from "../lib/auth.js";
import { z } from "zod";

const router = Router();

router.use(requireAuth);

async function getProjectWithStats(projectId: number, userId: number, userRole: string) {
  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, projectId))
    .limit(1);

  if (!project) return null;

  // Check access: admin/supervisor see all, PM sees created, members see assigned
  if (userRole === "TEAM_MEMBER") {
    const membership = await db
      .select({ id: projectMembersTable.id })
      .from(projectMembersTable)
      .where(
        and(
          eq(projectMembersTable.projectId, projectId),
          eq(projectMembersTable.userId, userId)
        )
      )
      .limit(1);
    if (membership.length === 0) return null;
  }

  const members = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
      avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .innerJoin(projectMembersTable, eq(projectMembersTable.userId, usersTable.id))
    .where(eq(projectMembersTable.projectId, projectId));

  const milestones = await db
    .select()
    .from(milestonesTable)
    .where(eq(milestonesTable.projectId, projectId));

  const tasks = await db
    .select({ status: tasksTable.status, dueDate: tasksTable.dueDate })
    .from(tasksTable)
    .where(eq(tasksTable.projectId, projectId));

  const now = new Date();
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === "DONE").length;
  const overdueTasks = tasks.filter(t => t.dueDate && t.dueDate < now && t.status !== "DONE").length;

  return {
    ...project,
    members,
    milestones,
    totalTasks,
    completedTasks,
    overdueTasks,
  };
}

router.get("/", async (req: AuthenticatedRequest, res) => {
  const user = req.user!;

  let projectIds: number[] = [];

  if (user.role === "ADMIN" || user.role === "SUPERVISOR") {
    const all = await db.select({ id: projectsTable.id }).from(projectsTable);
    projectIds = all.map(p => p.id);
  } else if (user.role === "PROJECT_MANAGER") {
    const myProjects = await db
      .select({ id: projectsTable.id })
      .from(projectsTable)
      .where(eq(projectsTable.createdById, user.id));
    const memberOf = await db
      .select({ projectId: projectMembersTable.projectId })
      .from(projectMembersTable)
      .where(eq(projectMembersTable.userId, user.id));
    const ids = new Set([...myProjects.map(p => p.id), ...memberOf.map(m => m.projectId)]);
    projectIds = [...ids];
  } else {
    const memberOf = await db
      .select({ projectId: projectMembersTable.projectId })
      .from(projectMembersTable)
      .where(eq(projectMembersTable.userId, user.id));
    projectIds = memberOf.map(m => m.projectId);
  }

  if (projectIds.length === 0) {
    res.json([]);
    return;
  }

  const results = await Promise.all(
    projectIds.map(id => getProjectWithStats(id, user.id, user.role))
  );

  res.json(results.filter(Boolean));
});

router.get("/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const project = await getProjectWithStats(id, req.user!.id, req.user!.role);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  res.json(project);
});

const createProjectSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  status: z.enum(["PLANNING", "ACTIVE", "ON_HOLD", "COMPLETED", "ARCHIVED"]).default("PLANNING"),
  startDate: z.string().datetime().optional(),
  deadline: z.string().datetime().optional(),
  memberIds: z.array(z.number()).optional(),
});

router.post("/", requireRole("ADMIN", "PROJECT_MANAGER"), async (req: AuthenticatedRequest, res) => {
  const parsed = createProjectSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.errors[0]?.message ?? "Invalid request" });
    return;
  }

  const { memberIds, ...projectData } = parsed.data;

  const [project] = await db
    .insert(projectsTable)
    .values({
      ...projectData,
      startDate: projectData.startDate ? new Date(projectData.startDate) : null,
      deadline: projectData.deadline ? new Date(projectData.deadline) : null,
      createdById: req.user!.id,
    })
    .returning();

  if (!project) {
    res.status(500).json({ error: "Failed to create project" });
    return;
  }

  // Add creator as member
  const memberIdsToAdd = new Set([req.user!.id, ...(memberIds ?? [])]);
  if (memberIdsToAdd.size > 0) {
    await db.insert(projectMembersTable).values(
      [...memberIdsToAdd].map(uid => ({ projectId: project.id, userId: uid }))
    );
  }

  res.status(201).json(project);
});

const updateProjectSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  status: z.enum(["PLANNING", "ACTIVE", "ON_HOLD", "COMPLETED", "ARCHIVED"]).optional(),
  startDate: z.string().datetime().optional().nullable(),
  deadline: z.string().datetime().optional().nullable(),
});

router.patch("/:id", requireRole("ADMIN", "PROJECT_MANAGER"), async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const parsed = updateProjectSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.startDate !== undefined) {
    updateData["startDate"] = parsed.data.startDate ? new Date(parsed.data.startDate) : null;
  }
  if (parsed.data.deadline !== undefined) {
    updateData["deadline"] = parsed.data.deadline ? new Date(parsed.data.deadline) : null;
  }

  const [updated] = await db
    .update(projectsTable)
    .set(updateData)
    .where(eq(projectsTable.id, id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  res.json(updated);
});

router.delete("/:id", requireRole("ADMIN", "PROJECT_MANAGER"), async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  await db.delete(projectsTable).where(eq(projectsTable.id, id));
  res.json({ success: true, message: "Project deleted" });
});

// Project Members
router.get("/:id/members", async (req, res) => {
  const projectId = parseInt(req.params["id"] ?? "0");
  if (isNaN(projectId)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const members = await db
    .select({
      id: projectMembersTable.id,
      projectId: projectMembersTable.projectId,
      userId: projectMembersTable.userId,
      joinedAt: projectMembersTable.joinedAt,
      user: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        avatarUrl: usersTable.avatarUrl,
        createdAt: usersTable.createdAt,
        lastSeenAt: usersTable.lastSeenAt,
      },
    })
    .from(projectMembersTable)
    .innerJoin(usersTable, eq(usersTable.id, projectMembersTable.userId))
    .where(eq(projectMembersTable.projectId, projectId));

  res.json(members);
});

router.post("/:id/members", requireRole("ADMIN", "PROJECT_MANAGER"), async (req, res) => {
  const projectId = parseInt(req.params["id"] ?? "0");
  if (isNaN(projectId)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const { userId } = req.body as { userId: number };
  if (!userId) {
    res.status(400).json({ error: "userId required" });
    return;
  }

  const [member] = await db
    .insert(projectMembersTable)
    .values({ projectId, userId })
    .returning();

  if (!member) {
    res.status(500).json({ error: "Failed to add member" });
    return;
  }

  const [user] = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
      avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);

  res.status(201).json({ ...member, user });
});

router.delete("/:id/members/:userId", requireRole("ADMIN", "PROJECT_MANAGER"), async (req, res) => {
  const projectId = parseInt(req.params["id"] ?? "0");
  const userId = parseInt(req.params["userId"] ?? "0");

  await db
    .delete(projectMembersTable)
    .where(
      and(
        eq(projectMembersTable.projectId, projectId),
        eq(projectMembersTable.userId, userId)
      )
    );

  res.json({ success: true, message: "Member removed" });
});

export default router;
