import { Router } from "express";
import { db } from "@workspace/db";
import {
  conversationsTable,
  conversationMembersTable,
  messagesTable,
  messageReactionsTable,
  usersTable,
  notificationsTable,
} from "@workspace/db";
import { eq, and, desc, lt, sql, count, inArray } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth.js";
import { sendMessageToConversation, sendNotificationToUser } from "../lib/pusher.js";
import { z } from "zod";

const router = Router();

router.use(requireAuth);

async function getMessageWithDetails(messageId: number) {
  const [message] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, messageId))
    .limit(1);

  if (!message) return null;

  const [sender] = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
      avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .where(eq(usersTable.id, message.senderId))
    .limit(1);

  const reactions = await db
    .select({
      id: messageReactionsTable.id,
      messageId: messageReactionsTable.messageId,
      userId: messageReactionsTable.userId,
      emoji: messageReactionsTable.emoji,
      user: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        avatarUrl: usersTable.avatarUrl,
        createdAt: usersTable.createdAt,
        lastSeenAt: usersTable.lastSeenAt,
      },
    })
    .from(messageReactionsTable)
    .innerJoin(usersTable, eq(usersTable.id, messageReactionsTable.userId))
    .where(eq(messageReactionsTable.messageId, messageId));

  return { ...message, sender, reactions };
}

async function getConversationWithDetails(convId: number, currentUserId: number) {
  const [conv] = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.id, convId))
    .limit(1);

  if (!conv) return null;

  const members = await db
    .select({
      id: conversationMembersTable.id,
      conversationId: conversationMembersTable.conversationId,
      userId: conversationMembersTable.userId,
      joinedAt: conversationMembersTable.joinedAt,
      lastReadAt: conversationMembersTable.lastReadAt,
      isAdmin: conversationMembersTable.isAdmin,
      user: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        avatarUrl: usersTable.avatarUrl,
        createdAt: usersTable.createdAt,
        lastSeenAt: usersTable.lastSeenAt,
      },
    })
    .from(conversationMembersTable)
    .innerJoin(usersTable, eq(usersTable.id, conversationMembersTable.userId))
    .where(eq(conversationMembersTable.conversationId, convId));

  const [lastMessage] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, convId))
    .orderBy(desc(messagesTable.createdAt))
    .limit(1);

  const lastMessageWithDetails = lastMessage ? await getMessageWithDetails(lastMessage.id) : null;

  const currentMember = members.find(m => m.userId === currentUserId);
  const lastReadAt = currentMember?.lastReadAt;

  let unreadCount = 0;
  if (lastReadAt) {
    const [unreadResult] = await db
      .select({ count: count() })
      .from(messagesTable)
      .where(
        and(
          eq(messagesTable.conversationId, convId),
          sql`${messagesTable.createdAt} > ${lastReadAt}`,
          sql`${messagesTable.senderId} != ${currentUserId}`
        )
      );
    unreadCount = Number(unreadResult?.count ?? 0);
  } else {
    const [totalResult] = await db
      .select({ count: count() })
      .from(messagesTable)
      .where(
        and(
          eq(messagesTable.conversationId, convId),
          sql`${messagesTable.senderId} != ${currentUserId}`
        )
      );
    unreadCount = Number(totalResult?.count ?? 0);
  }

  return {
    ...conv,
    members,
    lastMessage: lastMessageWithDetails,
    unreadCount,
  };
}

// GET /conversations
router.get("/", async (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;

  const memberships = await db
    .select({ conversationId: conversationMembersTable.conversationId })
    .from(conversationMembersTable)
    .where(eq(conversationMembersTable.userId, userId));

  const convIds = memberships.map(m => m.conversationId);
  if (convIds.length === 0) {
    res.json([]);
    return;
  }

  const results = await Promise.all(convIds.map(id => getConversationWithDetails(id, userId)));
  const filtered = results.filter(Boolean);

  // Sort by latest message
  filtered.sort((a, b) => {
    const aTime = a?.lastMessage?.createdAt?.getTime() ?? a?.createdAt?.getTime() ?? 0;
    const bTime = b?.lastMessage?.createdAt?.getTime() ?? b?.createdAt?.getTime() ?? 0;
    return bTime - aTime;
  });

  res.json(filtered);
});

// POST /conversations
const createConversationSchema = z.object({
  type: z.enum(["DIRECT", "GROUP"]),
  name: z.string().optional(),
  description: z.string().optional(),
  projectId: z.number().int().optional(),
  memberIds: z.array(z.number().int()),
});

router.post("/", async (req: AuthenticatedRequest, res) => {
  const parsed = createConversationSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const { type, name, description, projectId, memberIds } = parsed.data;

  if (type === "DIRECT" && memberIds.length !== 1) {
    res.status(400).json({ error: "Direct messages require exactly one other member" });
    return;
  }

  // For DMs, check if conversation already exists
  if (type === "DIRECT") {
    const otherId = memberIds[0]!;
    const existing = await db
      .select({ conversationId: conversationMembersTable.conversationId })
      .from(conversationMembersTable)
      .where(eq(conversationMembersTable.userId, req.user!.id));

    for (const { conversationId } of existing) {
      const conv = await db
        .select()
        .from(conversationsTable)
        .where(and(eq(conversationsTable.id, conversationId), eq(conversationsTable.type, "DIRECT")))
        .limit(1);

      if (conv.length > 0) {
        const otherMember = await db
          .select()
          .from(conversationMembersTable)
          .where(
            and(
              eq(conversationMembersTable.conversationId, conversationId),
              eq(conversationMembersTable.userId, otherId)
            )
          )
          .limit(1);

        if (otherMember.length > 0) {
          const result = await getConversationWithDetails(conversationId, req.user!.id);
          res.status(201).json(result);
          return;
        }
      }
    }
  }

  const [conv] = await db
    .insert(conversationsTable)
    .values({
      type,
      name: name ?? null,
      description: description ?? null,
      projectId: projectId ?? null,
      createdById: req.user!.id,
    })
    .returning();

  if (!conv) {
    res.status(500).json({ error: "Failed to create conversation" });
    return;
  }

  const allMemberIds = new Set([req.user!.id, ...memberIds]);
  await db.insert(conversationMembersTable).values(
    [...allMemberIds].map(uid => ({
      conversationId: conv.id,
      userId: uid,
      isAdmin: uid === req.user!.id,
    }))
  );

  const result = await getConversationWithDetails(conv.id, req.user!.id);
  res.status(201).json(result);
});

// GET /conversations/:id
router.get("/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");

  const membership = await db
    .select()
    .from(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, id),
        eq(conversationMembersTable.userId, req.user!.id)
      )
    )
    .limit(1);

  if (membership.length === 0) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const result = await getConversationWithDetails(id, req.user!.id);
  res.json(result);
});

// PATCH /conversations/:id
router.patch("/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  const { name, description } = req.body as { name?: string; description?: string };

  const membership = await db
    .select()
    .from(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, id),
        eq(conversationMembersTable.userId, req.user!.id),
        eq(conversationMembersTable.isAdmin, true)
      )
    )
    .limit(1);

  if (membership.length === 0) {
    res.status(403).json({ error: "Only group admins can update conversations" });
    return;
  }

  const [updated] = await db
    .update(conversationsTable)
    .set({ name: name ?? null, description: description ?? null })
    .where(eq(conversationsTable.id, id))
    .returning();

  const result = await getConversationWithDetails(id, req.user!.id);
  res.json(result);
});

// DELETE /conversations/:id
router.delete("/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");

  const membership = await db
    .select()
    .from(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, id),
        eq(conversationMembersTable.userId, req.user!.id),
        eq(conversationMembersTable.isAdmin, true)
      )
    )
    .limit(1);

  if (membership.length === 0) {
    res.status(403).json({ error: "Only group admins can delete conversations" });
    return;
  }

  await db.delete(conversationsTable).where(eq(conversationsTable.id, id));
  res.json({ success: true, message: "Conversation deleted" });
});

// GET /conversations/:id/messages
router.get("/:id/messages", async (req: AuthenticatedRequest, res) => {
  const convId = parseInt(req.params["id"] ?? "0");
  const { before, limit } = req.query as { before?: string; limit?: string };

  const pageLimit = Math.min(parseInt(limit ?? "30"), 50);

  const membership = await db
    .select()
    .from(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, convId),
        eq(conversationMembersTable.userId, req.user!.id)
      )
    )
    .limit(1);

  if (membership.length === 0) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  let messagesQuery = db
    .select()
    .from(messagesTable)
    .where(
      before
        ? and(
            eq(messagesTable.conversationId, convId),
            lt(messagesTable.id, parseInt(before))
          )
        : eq(messagesTable.conversationId, convId)
    )
    .orderBy(desc(messagesTable.createdAt))
    .limit(pageLimit);

  const messages = await messagesQuery;
  messages.reverse(); // Chronological order

  const results = await Promise.all(messages.map(m => getMessageWithDetails(m.id)));
  res.json(results.filter(Boolean));
});

// POST /conversations/:id/messages
router.post("/:id/messages", async (req: AuthenticatedRequest, res) => {
  const convId = parseInt(req.params["id"] ?? "0");
  const { content, fileUrl, fileName } = req.body as {
    content: string;
    fileUrl?: string;
    fileName?: string;
  };

  if (!content) {
    res.status(400).json({ error: "Content required" });
    return;
  }

  const membership = await db
    .select()
    .from(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, convId),
        eq(conversationMembersTable.userId, req.user!.id)
      )
    )
    .limit(1);

  if (membership.length === 0) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const [message] = await db
    .insert(messagesTable)
    .values({
      conversationId: convId,
      senderId: req.user!.id,
      content,
      fileUrl: fileUrl ?? null,
      fileName: fileName ?? null,
    })
    .returning();

  if (!message) {
    res.status(500).json({ error: "Failed to send message" });
    return;
  }

  const messageWithDetails = await getMessageWithDetails(message.id);

  // Notify other members
  const [conv] = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.id, convId))
    .limit(1);

  const members = await db
    .select({ userId: conversationMembersTable.userId })
    .from(conversationMembersTable)
    .where(eq(conversationMembersTable.conversationId, convId));

  for (const { userId } of members) {
    if (userId !== req.user!.id) {
      const notifType = conv?.type === "GROUP" ? "GROUP_MESSAGE" : "MESSAGE_RECEIVED";
      const [notif] = await db.insert(notificationsTable).values({
        userId,
        type: notifType,
        title: conv?.type === "GROUP" ? `New message in ${conv.name ?? "group"}` : `New message from ${req.user!.name}`,
        body: content.slice(0, 100),
        resourceId: convId,
        resourceType: "conversation",
      }).returning();

      if (notif) {
        await sendNotificationToUser(userId, notif);
      }
    }
  }

  // Broadcast to conversation channel
  await sendMessageToConversation(convId, messageWithDetails);

  res.status(201).json(messageWithDetails);
});

// PATCH /messages/:id
router.patch("/messages/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  const { content } = req.body as { content: string };

  if (!content) {
    res.status(400).json({ error: "Content required" });
    return;
  }

  const [existing] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, id))
    .limit(1);

  if (!existing || existing.senderId !== req.user!.id) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db
    .update(messagesTable)
    .set({ content, isEdited: true, updatedAt: new Date() })
    .where(eq(messagesTable.id, id));

  const result = await getMessageWithDetails(id);
  res.json(result);
});

// DELETE /messages/:id
router.delete("/messages/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");

  const [existing] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, id))
    .limit(1);

  if (!existing || (existing.senderId !== req.user!.id && req.user!.role !== "ADMIN")) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(messagesTable).where(eq(messagesTable.id, id));
  res.json({ success: true, message: "Message deleted" });
});

// POST /messages/:id/react
router.post("/messages/:id/react", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  const { emoji } = req.body as { emoji: string };

  if (!emoji) {
    res.status(400).json({ error: "Emoji required" });
    return;
  }

  const existing = await db
    .select()
    .from(messageReactionsTable)
    .where(
      and(
        eq(messageReactionsTable.messageId, id),
        eq(messageReactionsTable.userId, req.user!.id),
        eq(messageReactionsTable.emoji, emoji)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    await db.delete(messageReactionsTable).where(eq(messageReactionsTable.id, existing[0]!.id));
  } else {
    await db.insert(messageReactionsTable).values({
      messageId: id,
      userId: req.user!.id,
      emoji,
    });
  }

  const result = await getMessageWithDetails(id);
  res.json(result);
});

// POST /messages/:id/pin
router.post("/messages/:id/pin", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");

  const [existing] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Message not found" });
    return;
  }

  await db
    .update(messagesTable)
    .set({ isPinned: !existing.isPinned })
    .where(eq(messagesTable.id, id));

  const result = await getMessageWithDetails(id);
  res.json(result);
});

// POST /conversations/:id/members
router.post("/:id/members", async (req: AuthenticatedRequest, res) => {
  const convId = parseInt(req.params["id"] ?? "0");
  const { userId } = req.body as { userId: number };

  const membership = await db
    .select()
    .from(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, convId),
        eq(conversationMembersTable.userId, req.user!.id),
        eq(conversationMembersTable.isAdmin, true)
      )
    )
    .limit(1);

  if (membership.length === 0) {
    res.status(403).json({ error: "Only admins can add members" });
    return;
  }

  await db.insert(conversationMembersTable).values({
    conversationId: convId,
    userId,
    isAdmin: false,
  });

  res.status(201).json({ success: true, message: "Member added" });
});

// DELETE /conversations/:id/members/:userId
router.delete("/:id/members/:userId", async (req: AuthenticatedRequest, res) => {
  const convId = parseInt(req.params["id"] ?? "0");
  const userId = parseInt(req.params["userId"] ?? "0");

  // Can remove yourself or admin can remove anyone
  if (userId !== req.user!.id) {
    const membership = await db
      .select()
      .from(conversationMembersTable)
      .where(
        and(
          eq(conversationMembersTable.conversationId, convId),
          eq(conversationMembersTable.userId, req.user!.id),
          eq(conversationMembersTable.isAdmin, true)
        )
      )
      .limit(1);

    if (membership.length === 0) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
  }

  await db
    .delete(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, convId),
        eq(conversationMembersTable.userId, userId)
      )
    );

  res.json({ success: true, message: "Member removed" });
});

// POST /conversations/:id/read
router.post("/:id/read", async (req: AuthenticatedRequest, res) => {
  const convId = parseInt(req.params["id"] ?? "0");

  await db
    .update(conversationMembersTable)
    .set({ lastReadAt: new Date() })
    .where(
      and(
        eq(conversationMembersTable.conversationId, convId),
        eq(conversationMembersTable.userId, req.user!.id)
      )
    );

  res.json({ success: true, message: "Marked as read" });
});

export default router;
