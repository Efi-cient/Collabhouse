import { Router } from "express";
import { db } from "@workspace/db";
import { milestonesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireRole } from "../lib/auth.js";
import { z } from "zod";

const router = Router();

router.use(requireAuth);

const createMilestoneSchema = z.object({
  title: z.string().min(1),
  targetDate: z.string().datetime().optional(),
});

const updateMilestoneSchema = z.object({
  title: z.string().min(1).optional(),
  targetDate: z.string().datetime().optional().nullable(),
  isCompleted: z.boolean().optional(),
});

// Create milestone under a project (via /projects/:id/milestones)
export async function createMilestoneHandler(req: { body: unknown; params: Record<string, string | undefined> }, res: { status: (n: number) => { json: (d: unknown) => void }; json: (d: unknown) => void }) {
  const projectId = parseInt(req.params["id"] ?? "0");
  if (isNaN(projectId)) {
    res.status(400).json({ error: "Invalid project ID" });
    return;
  }

  const parsed = createMilestoneSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const [milestone] = await db
    .insert(milestonesTable)
    .values({
      projectId,
      title: parsed.data.title,
      targetDate: parsed.data.targetDate ? new Date(parsed.data.targetDate) : null,
    })
    .returning();

  res.status(201).json(milestone);
}

export async function getMilestonesHandler(req: { params: Record<string, string | undefined> }, res: { status: (n: number) => { json: (d: unknown) => void }; json: (d: unknown) => void }) {
  const projectId = parseInt(req.params["id"] ?? "0");
  if (isNaN(projectId)) {
    res.status(400).json({ error: "Invalid project ID" });
    return;
  }

  const milestones = await db
    .select()
    .from(milestonesTable)
    .where(eq(milestonesTable.projectId, projectId))
    .orderBy(milestonesTable.targetDate);

  res.json(milestones);
}

// Standalone milestone routes
router.patch("/:id", requireRole("ADMIN", "PROJECT_MANAGER"), async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const parsed = updateMilestoneSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const updateData: Record<string, unknown> = {};
  if (parsed.data.title !== undefined) updateData["title"] = parsed.data.title;
  if (parsed.data.isCompleted !== undefined) updateData["isCompleted"] = parsed.data.isCompleted;
  if (parsed.data.targetDate !== undefined) {
    updateData["targetDate"] = parsed.data.targetDate ? new Date(parsed.data.targetDate) : null;
  }

  const [updated] = await db
    .update(milestonesTable)
    .set(updateData)
    .where(eq(milestonesTable.id, id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Milestone not found" });
    return;
  }

  res.json(updated);
});

router.delete("/:id", requireRole("ADMIN", "PROJECT_MANAGER"), async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  await db.delete(milestonesTable).where(eq(milestonesTable.id, id));
  res.json({ success: true, message: "Milestone deleted" });
});

export default router;
