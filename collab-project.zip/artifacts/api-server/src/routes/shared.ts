import { Router } from "express";
import { db } from "@workspace/db";
import {
  commentsTable,
  fileAttachmentsTable,
  subTasksTable,
  usersTable,
} from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth.js";

const router = Router();

router.use(requireAuth);

// Comment operations
router.patch("/comments/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  const { content } = req.body as { content: string };

  if (!content) {
    res.status(400).json({ error: "Content required" });
    return;
  }

  const [existing] = await db
    .select()
    .from(commentsTable)
    .where(eq(commentsTable.id, id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }

  if (existing.userId !== req.user!.id && req.user!.role !== "ADMIN") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const [updated] = await db
    .update(commentsTable)
    .set({ content, updatedAt: new Date() })
    .where(eq(commentsTable.id, id))
    .returning();

  const [author] = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
      avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .where(eq(usersTable.id, existing.userId))
    .limit(1);

  res.json({ ...updated, author, replies: [] });
});

router.delete("/comments/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");

  const [existing] = await db
    .select()
    .from(commentsTable)
    .where(eq(commentsTable.id, id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }

  if (existing.userId !== req.user!.id && req.user!.role !== "ADMIN") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(commentsTable).where(eq(commentsTable.id, id));
  res.json({ success: true, message: "Comment deleted" });
});

// File operations
router.delete("/files/:id", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");

  const [existing] = await db
    .select()
    .from(fileAttachmentsTable)
    .where(eq(fileAttachmentsTable.id, id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "File not found" });
    return;
  }

  if (existing.uploadedById !== req.user!.id && req.user!.role !== "ADMIN") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(fileAttachmentsTable).where(eq(fileAttachmentsTable.id, id));
  res.json({ success: true, message: "File deleted" });
});

// Subtask operations
router.patch("/subtasks/:id", async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  const { title, isCompleted } = req.body as { title?: string; isCompleted?: boolean };

  const updateData: Record<string, unknown> = {};
  if (title !== undefined) updateData["title"] = title;
  if (isCompleted !== undefined) updateData["isCompleted"] = isCompleted;

  const [updated] = await db
    .update(subTasksTable)
    .set(updateData)
    .where(eq(subTasksTable.id, id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Subtask not found" });
    return;
  }

  res.json(updated);
});

router.delete("/subtasks/:id", async (req, res) => {
  const id = parseInt(req.params["id"] ?? "0");
  await db.delete(subTasksTable).where(eq(subTasksTable.id, id));
  res.json({ success: true, message: "Subtask deleted" });
});

export default router;
