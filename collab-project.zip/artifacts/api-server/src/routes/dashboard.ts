import { Router } from "express";
import { db } from "@workspace/db";
import {
  usersTable,
  projectsTable,
  projectMembersTable,
  tasksTable,
  taskAssigneesTable,
  milestonesTable,
  commentsTable,
  activityLogsTable,
  notificationsTable,
  conversationsTable,
  conversationMembersTable,
  messagesTable,
} from "@workspace/db";
import { eq, and, count, gte, lt, lte, desc, inArray, or, sql } from "drizzle-orm";
import { requireAuth, requireRole, type AuthenticatedRequest } from "../lib/auth.js";

const router = Router();

router.use(requireAuth);

// Admin Dashboard
router.get("/admin", requireRole("ADMIN"), async (req: AuthenticatedRequest, res) => {
  const [totalUsersResult] = await db.select({ count: count() }).from(usersTable);
  const [activeProjectsResult] = await db
    .select({ count: count() })
    .from(projectsTable)
    .where(eq(projectsTable.status, "ACTIVE"));

  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const [tasksThisMonthResult] = await db
    .select({ count: count() })
    .from(tasksTable)
    .where(gte(tasksTable.createdAt, startOfMonth));

  const projects = await db.select().from(projectsTable);
  const tasksByProject = await Promise.all(
    projects.map(async (project) => {
      const [total] = await db
        .select({ count: count() })
        .from(tasksTable)
        .where(eq(tasksTable.projectId, project.id));
      const [completed] = await db
        .select({ count: count() })
        .from(tasksTable)
        .where(and(eq(tasksTable.projectId, project.id), eq(tasksTable.status, "DONE")));

      return {
        projectId: project.id,
        projectName: project.name,
        total: Number(total?.count ?? 0),
        completed: Number(completed?.count ?? 0),
      };
    })
  );

  const recentActivity = await db
    .select({
      id: activityLogsTable.id,
      taskId: activityLogsTable.taskId,
      userId: activityLogsTable.userId,
      eventType: activityLogsTable.eventType,
      metadata: activityLogsTable.metadata,
      createdAt: activityLogsTable.createdAt,
      user: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        avatarUrl: usersTable.avatarUrl,
        createdAt: usersTable.createdAt,
        lastSeenAt: usersTable.lastSeenAt,
      },
    })
    .from(activityLogsTable)
    .innerJoin(usersTable, eq(usersTable.id, activityLogsTable.userId))
    .orderBy(desc(activityLogsTable.createdAt))
    .limit(20);

  res.json({
    totalUsers: Number(totalUsersResult?.count ?? 0),
    activeProjects: Number(activeProjectsResult?.count ?? 0),
    tasksCreatedThisMonth: Number(tasksThisMonthResult?.count ?? 0),
    tasksByProject,
    recentActivity,
  });
});

// PM Dashboard
router.get("/pm", requireRole("ADMIN", "PROJECT_MANAGER"), async (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;

  const myProjectIds = await db
    .select({ id: projectsTable.id })
    .from(projectsTable)
    .where(eq(projectsTable.createdById, userId));

  const memberProjects = await db
    .select({ projectId: projectMembersTable.projectId })
    .from(projectMembersTable)
    .where(eq(projectMembersTable.userId, userId));

  const allIds = new Set([...myProjectIds.map(p => p.id), ...memberProjects.map(p => p.projectId)]);
  const projectIds = [...allIds];

  const now = new Date();

  let myProjects = [];
  if (projectIds.length > 0) {
    const projects = await db
      .select()
      .from(projectsTable)
      .where(inArray(projectsTable.id, projectIds));

    myProjects = await Promise.all(
      projects.map(async (project) => {
        const members = await db
          .select({
            id: usersTable.id,
            name: usersTable.name,
            email: usersTable.email,
            role: usersTable.role,
            isActive: usersTable.isActive,
            avatarUrl: usersTable.avatarUrl,
            createdAt: usersTable.createdAt,
            lastSeenAt: usersTable.lastSeenAt,
          })
          .from(usersTable)
          .innerJoin(projectMembersTable, eq(projectMembersTable.userId, usersTable.id))
          .where(eq(projectMembersTable.projectId, project.id));

        const milestones = await db.select().from(milestonesTable).where(eq(milestonesTable.projectId, project.id));
        const tasks = await db.select().from(tasksTable).where(eq(tasksTable.projectId, project.id));

        return {
          ...project,
          members,
          milestones,
          totalTasks: tasks.length,
          completedTasks: tasks.filter(t => t.status === "DONE").length,
          overdueTasks: tasks.filter(t => t.dueDate && t.dueDate < now && t.status !== "DONE").length,
        };
      })
    );
  }

  // Overdue tasks
  let overdueTasks: unknown[] = [];
  if (projectIds.length > 0) {
    const overdue = await db
      .select()
      .from(tasksTable)
      .where(
        and(
          inArray(tasksTable.projectId, projectIds),
          lt(tasksTable.dueDate, now),
          sql`${tasksTable.status} != 'DONE'`
        )
      )
      .limit(20);

    overdueTasks = await Promise.all(overdue.map(async (t) => {
      const assignees = await db
        .select({
          id: usersTable.id, name: usersTable.name, email: usersTable.email,
          role: usersTable.role, isActive: usersTable.isActive, avatarUrl: usersTable.avatarUrl,
          createdAt: usersTable.createdAt, lastSeenAt: usersTable.lastSeenAt,
        })
        .from(usersTable)
        .innerJoin(taskAssigneesTable, eq(taskAssigneesTable.userId, usersTable.id))
        .where(eq(taskAssigneesTable.taskId, t.id));

      return { ...t, assignees, subtasks: [], commentCount: 0, fileCount: 0 };
    }));
  }

  // Team workload
  const teamWorkload = await db
    .select({
      userId: taskAssigneesTable.userId,
      userName: usersTable.name,
    })
    .from(taskAssigneesTable)
    .innerJoin(usersTable, eq(usersTable.id, taskAssigneesTable.userId))
    .innerJoin(tasksTable, eq(tasksTable.id, taskAssigneesTable.taskId))
    .where(
      projectIds.length > 0
        ? and(
            inArray(tasksTable.projectId, projectIds),
            sql`${tasksTable.status} != 'DONE'`
          )
        : sql`false`
    );

  const workloadMap = new Map<number, { userId: number; userName: string; taskCount: number }>();
  for (const row of teamWorkload) {
    const existing = workloadMap.get(row.userId);
    if (existing) {
      existing.taskCount++;
    } else {
      workloadMap.set(row.userId, { userId: row.userId, userName: row.userName, taskCount: 1 });
    }
  }

  // Upcoming milestones (14 days)
  const in14Days = new Date();
  in14Days.setDate(in14Days.getDate() + 14);

  let upcomingMilestones: unknown[] = [];
  if (projectIds.length > 0) {
    const milestones = await db
      .select({
        id: milestonesTable.id,
        projectId: milestonesTable.projectId,
        title: milestonesTable.title,
        targetDate: milestonesTable.targetDate,
        isCompleted: milestonesTable.isCompleted,
        projectName: projectsTable.name,
      })
      .from(milestonesTable)
      .innerJoin(projectsTable, eq(projectsTable.id, milestonesTable.projectId))
      .where(
        and(
          inArray(milestonesTable.projectId, projectIds),
          eq(milestonesTable.isCompleted, false),
          gte(milestonesTable.targetDate, now),
          lte(milestonesTable.targetDate, in14Days)
        )
      )
      .orderBy(milestonesTable.targetDate);

    upcomingMilestones = milestones;
  }

  res.json({
    myProjects,
    overdueTasks,
    teamWorkload: [...workloadMap.values()],
    upcomingMilestones,
  });
});

// Member Dashboard
router.get("/member", requireRole("ADMIN", "PROJECT_MANAGER", "TEAM_MEMBER"), async (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const now = new Date();
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  // Tasks due today or overdue
  const assignedTaskIds = await db
    .select({ taskId: taskAssigneesTable.taskId })
    .from(taskAssigneesTable)
    .where(eq(taskAssigneesTable.userId, userId));

  const taskIds = assignedTaskIds.map(a => a.taskId);

  let myTasksToday: unknown[] = [];
  let taskStatusBreakdown: { status: string; count: number }[] = [];

  if (taskIds.length > 0) {
    const todayTasks = await db
      .select()
      .from(tasksTable)
      .where(
        and(
          inArray(tasksTable.id, taskIds),
          sql`${tasksTable.status} != 'DONE'`,
          lte(tasksTable.dueDate, endOfDay)
        )
      )
      .limit(10);

    myTasksToday = await Promise.all(todayTasks.map(async (t) => ({
      ...t,
      assignees: [],
      subtasks: [],
      commentCount: 0,
      fileCount: 0,
    })));

    // Status breakdown
    const allAssigned = await db
      .select({ status: tasksTable.status })
      .from(tasksTable)
      .where(inArray(tasksTable.id, taskIds));

    const statusMap = new Map<string, number>();
    for (const t of allAssigned) {
      statusMap.set(t.status, (statusMap.get(t.status) ?? 0) + 1);
    }
    taskStatusBreakdown = [...statusMap.entries()].map(([status, count]) => ({ status, count }));
  }

  // Recent comments on my tasks
  let recentComments: unknown[] = [];
  if (taskIds.length > 0) {
    const comments = await db
      .select({
        id: commentsTable.id,
        taskId: commentsTable.taskId,
        userId: commentsTable.userId,
        content: commentsTable.content,
        parentId: commentsTable.parentId,
        createdAt: commentsTable.createdAt,
        updatedAt: commentsTable.updatedAt,
        author: {
          id: usersTable.id,
          name: usersTable.name,
          email: usersTable.email,
          role: usersTable.role,
          isActive: usersTable.isActive,
          avatarUrl: usersTable.avatarUrl,
          createdAt: usersTable.createdAt,
          lastSeenAt: usersTable.lastSeenAt,
        },
      })
      .from(commentsTable)
      .innerJoin(usersTable, eq(usersTable.id, commentsTable.userId))
      .where(
        and(
          inArray(commentsTable.taskId, taskIds),
          sql`${commentsTable.userId} != ${userId}`
        )
      )
      .orderBy(desc(commentsTable.createdAt))
      .limit(5);

    recentComments = comments.map(c => ({ ...c, replies: [] }));
  }

  // Unread messages
  const memberships = await db
    .select()
    .from(conversationMembersTable)
    .where(eq(conversationMembersTable.userId, userId));

  let unreadMessagesCount = 0;
  for (const membership of memberships) {
    const lastReadAt = membership.lastReadAt;
    const [result] = await db
      .select({ count: count() })
      .from(messagesTable)
      .where(
        and(
          eq(messagesTable.conversationId, membership.conversationId),
          sql`${messagesTable.senderId} != ${userId}`,
          lastReadAt ? sql`${messagesTable.createdAt} > ${lastReadAt}` : sql`true`
        )
      );
    unreadMessagesCount += Number(result?.count ?? 0);
  }

  res.json({
    myTasksToday,
    taskStatusBreakdown,
    recentComments,
    unreadMessagesCount,
  });
});

// Supervisor Dashboard
router.get("/supervisor", requireRole("ADMIN", "SUPERVISOR"), async (req: AuthenticatedRequest, res) => {
  const projects = await db.select().from(projectsTable);
  const now = new Date();

  const projectSummaries = await Promise.all(
    projects.map(async (project) => {
      const members = await db
        .select({
          id: usersTable.id, name: usersTable.name, email: usersTable.email,
          role: usersTable.role, isActive: usersTable.isActive, avatarUrl: usersTable.avatarUrl,
          createdAt: usersTable.createdAt, lastSeenAt: usersTable.lastSeenAt,
        })
        .from(usersTable)
        .innerJoin(projectMembersTable, eq(projectMembersTable.userId, usersTable.id))
        .where(eq(projectMembersTable.projectId, project.id));

      const milestones = await db.select().from(milestonesTable).where(eq(milestonesTable.projectId, project.id));
      const tasks = await db.select().from(tasksTable).where(eq(tasksTable.projectId, project.id));

      return {
        ...project,
        members,
        milestones,
        totalTasks: tasks.length,
        completedTasks: tasks.filter(t => t.status === "DONE").length,
        overdueTasks: tasks.filter(t => t.dueDate && t.dueDate < now && t.status !== "DONE").length,
      };
    })
  );

  const milestones = await db
    .select({
      id: milestonesTable.id,
      projectId: milestonesTable.projectId,
      title: milestonesTable.title,
      targetDate: milestonesTable.targetDate,
      isCompleted: milestonesTable.isCompleted,
      projectName: projectsTable.name,
    })
    .from(milestonesTable)
    .innerJoin(projectsTable, eq(projectsTable.id, milestonesTable.projectId))
    .orderBy(milestonesTable.targetDate);

  // Health summary
  let onTrack = 0, atRisk = 0, overdue = 0;
  for (const p of projectSummaries) {
    if (p.overdueTasks > 0) {
      overdue++;
    } else if (p.deadline && p.deadline < new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)) {
      atRisk++;
    } else {
      onTrack++;
    }
  }

  res.json({
    projectSummaries,
    milestones,
    healthSummary: { onTrack, atRisk, overdue },
  });
});

export default router;
