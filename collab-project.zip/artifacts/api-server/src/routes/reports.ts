import { Router } from "express";
import { db } from "@workspace/db";
import {
  projectsTable,
  projectMembersTable,
  tasksTable,
  taskAssigneesTable,
  milestonesTable,
  usersTable,
} from "@workspace/db";
import { eq, and, lt, sql, inArray } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth.js";

const router = Router();

router.use(requireAuth);

router.get("/project/:id", async (req: AuthenticatedRequest, res) => {
  const projectId = parseInt(req.params["id"] ?? "0");
  if (isNaN(projectId)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, projectId))
    .limit(1);

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const members = await db
    .select({
      id: usersTable.id, name: usersTable.name, email: usersTable.email,
      role: usersTable.role, isActive: usersTable.isActive, avatarUrl: usersTable.avatarUrl,
      createdAt: usersTable.createdAt, lastSeenAt: usersTable.lastSeenAt,
    })
    .from(usersTable)
    .innerJoin(projectMembersTable, eq(projectMembersTable.userId, usersTable.id))
    .where(eq(projectMembersTable.projectId, projectId));

  const milestones = await db
    .select()
    .from(milestonesTable)
    .where(eq(milestonesTable.projectId, projectId));

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.projectId, projectId));

  const now = new Date();
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === "DONE").length;
  const overdueTasks = tasks.filter(t => t.dueDate && t.dueDate < now && t.status !== "DONE").length;

  // Status breakdown
  const statusMap = new Map<string, number>();
  for (const t of tasks) {
    statusMap.set(t.status, (statusMap.get(t.status) ?? 0) + 1);
  }
  const tasksByStatus = [...statusMap.entries()].map(([status, count]) => ({ status, count }));

  // Overdue tasks with assignees
  const overdueTasksWithDetails = await Promise.all(
    tasks
      .filter(t => t.dueDate && t.dueDate < now && t.status !== "DONE")
      .map(async (t) => {
        const assignees = await db
          .select({
            id: usersTable.id, name: usersTable.name, email: usersTable.email,
            role: usersTable.role, isActive: usersTable.isActive, avatarUrl: usersTable.avatarUrl,
            createdAt: usersTable.createdAt, lastSeenAt: usersTable.lastSeenAt,
          })
          .from(usersTable)
          .innerJoin(taskAssigneesTable, eq(taskAssigneesTable.userId, usersTable.id))
          .where(eq(taskAssigneesTable.taskId, t.id));

        return { ...t, assignees, subtasks: [], commentCount: 0, fileCount: 0 };
      })
  );

  // Member contributions
  const memberContributions = await Promise.all(
    members.map(async (member) => {
      const assignedTaskIds = await db
        .select({ taskId: taskAssigneesTable.taskId })
        .from(taskAssigneesTable)
        .where(eq(taskAssigneesTable.userId, member.id));

      const memberTaskIds = assignedTaskIds.map(a => a.taskId);
      const memberTasks = tasks.filter(t => memberTaskIds.includes(t.id));

      return {
        userId: member.id,
        userName: member.name,
        tasksCompleted: memberTasks.filter(t => t.status === "DONE").length,
        tasksTotal: memberTasks.length,
      };
    })
  );

  const projectWithStats = {
    ...project,
    members,
    milestones,
    totalTasks,
    completedTasks,
    overdueTasks,
  };

  res.json({
    project: projectWithStats,
    milestones,
    tasksByStatus,
    overdueTasks: overdueTasksWithDetails,
    memberContributions,
  });
});

export default router;
