import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import usersRouter from "./users.js";
import projectsRouter from "./projects.js";
import milestonesRouter from "./milestones.js";
import tasksRouter from "./tasks.js";
import sharedRouter from "./shared.js";
import messagingRouter from "./messaging.js";
import notificationsRouter from "./notifications.js";
import dashboardRouter from "./dashboard.js";
import reportsRouter from "./reports.js";
import pusherAuthRouter from "./pusherAuth.js";
import { getMilestonesHandler, createMilestoneHandler } from "./milestones.js";
import { requireAuth, requireRole } from "../lib/auth.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/projects", projectsRouter);
router.use("/milestones", milestonesRouter);
router.use("/tasks", tasksRouter);
router.use(sharedRouter);
router.use("/conversations", messagingRouter);
router.use("/notifications", notificationsRouter);
router.use("/dashboard", dashboardRouter);
router.use("/reports", reportsRouter);
router.use("/pusher/auth", pusherAuthRouter);

// Project milestone sub-routes
router.get("/projects/:id/milestones", requireAuth, getMilestonesHandler as any);
router.post("/projects/:id/milestones", requireAuth, requireRole("ADMIN", "PROJECT_MANAGER"), createMilestoneHandler as any);

export default router;
