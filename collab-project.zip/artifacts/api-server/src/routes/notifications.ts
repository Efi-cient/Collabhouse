import { Router } from "express";
import { db } from "@workspace/db";
import { notificationsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth.js";

const router = Router();

router.use(requireAuth);

router.get("/", async (req: AuthenticatedRequest, res) => {
  const { unreadOnly, limit } = req.query as { unreadOnly?: string; limit?: string };
  const pageLimit = parseInt(limit ?? "50");

  let query = db
    .select()
    .from(notificationsTable)
    .where(
      unreadOnly === "true"
        ? and(
            eq(notificationsTable.userId, req.user!.id),
            eq(notificationsTable.isRead, false)
          )
        : eq(notificationsTable.userId, req.user!.id)
    )
    .orderBy(desc(notificationsTable.createdAt))
    .limit(pageLimit);

  const notifications = await query;
  res.json(notifications);
});

router.post("/read-all", async (req: AuthenticatedRequest, res) => {
  await db
    .update(notificationsTable)
    .set({ isRead: true })
    .where(
      and(
        eq(notificationsTable.userId, req.user!.id),
        eq(notificationsTable.isRead, false)
      )
    );

  res.json({ success: true, message: "All notifications marked as read" });
});

router.post("/:id/read", async (req: AuthenticatedRequest, res) => {
  const id = parseInt(req.params["id"] ?? "0");

  const [notif] = await db
    .update(notificationsTable)
    .set({ isRead: true })
    .where(
      and(
        eq(notificationsTable.id, id),
        eq(notificationsTable.userId, req.user!.id)
      )
    )
    .returning();

  if (!notif) {
    res.status(404).json({ error: "Notification not found" });
    return;
  }

  res.json(notif);
});

export default router;
