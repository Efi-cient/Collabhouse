import { create } from 'zustand';
import { User } from '@workspace/api-client-react';

interface AuthState {
  token: string | null;
  user: User | null;
  isAuthenticated: boolean;
  setAuth: (token: string, user: User) => void;
  clearAuth: () => void;
}

// Check local storage for initial state to prevent flash of login screen
const initialToken = localStorage.getItem('auth_token');
const initialUserStr = localStorage.getItem('auth_user');
let initialUser: User | null = null;

try {
  if (initialUserStr) {
    initialUser = JSON.parse(initialUserStr);
  }
} catch (e) {
  console.error("Failed to parse user from local storage");
}

export const useAuthStore = create<AuthState>((set) => ({
  token: initialToken,
  user: initialUser,
  isAuthenticated: !!initialToken,
  setAuth: (token, user) => {
    localStorage.setItem('auth_token', token);
    localStorage.setItem('auth_user', JSON.stringify(user));
    set({ token, user, isAuthenticated: true });
  },
  clearAuth: () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_user');
    set({ token: null, user: null, isAuthenticated: false });
  },
}));
