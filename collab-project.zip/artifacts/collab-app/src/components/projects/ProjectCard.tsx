import { ProjectWithStats } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Calendar, CheckCircle2, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'wouter';

export function ProjectCard({ project }: { project: ProjectWithStats }) {
  const percentComplete = project.totalTasks > 0 
    ? Math.round((project.completedTasks / project.totalTasks) * 100) 
    : 0;

  return (
    <Link href={`/projects/${project.id}`}>
      <Card className="cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 hover:border-primary/30 border border-border group overflow-hidden bg-card">
        <div className="h-2 w-full bg-secondary">
          <div 
            className="h-full bg-primary transition-all duration-1000 ease-out" 
            style={{ width: `${percentComplete}%` }}
          />
        </div>
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h3 className="font-display font-bold text-xl text-foreground group-hover:text-primary transition-colors line-clamp-1">
              {project.name}
            </h3>
            <Badge variant={project.status.toLowerCase() as any} className="shrink-0 uppercase text-[10px] tracking-wider">
              {project.status.replace('_', ' ')}
            </Badge>
          </div>
          
          <p className="text-sm text-muted-foreground line-clamp-2 mb-6 h-10">
            {project.description || "No description provided."}
          </p>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="space-y-1.5">
              <div className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" /> Deadline
              </div>
              <div className="text-sm font-semibold text-foreground">
                {project.deadline ? format(new Date(project.deadline), 'MMM d, yyyy') : 'No deadline'}
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" /> Progress
              </div>
              <div className="text-sm font-semibold text-foreground">
                {project.completedTasks} / {project.totalTasks} Tasks
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex -space-x-2 overflow-hidden">
              {project.members.slice(0, 4).map((member) => (
                <Avatar key={member.id} className="inline-block border-2 border-background w-8 h-8">
                  <AvatarImage src={member.avatarUrl || ''} />
                  <AvatarFallback className="text-xs bg-primary/10 text-primary">{member.name.charAt(0)}</AvatarFallback>
                </Avatar>
              ))}
              {project.members.length > 4 && (
                <div className="w-8 h-8 rounded-full bg-secondary border-2 border-background flex items-center justify-center text-xs font-medium text-secondary-foreground z-10">
                  +{project.members.length - 4}
                </div>
              )}
            </div>

            {project.overdueTasks > 0 && (
              <div className="flex items-center gap-1.5 text-xs font-medium text-destructive bg-destructive/10 px-2 py-1 rounded-md">
                <AlertCircle className="w-3.5 h-3.5" />
                {project.overdueTasks} overdue
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
