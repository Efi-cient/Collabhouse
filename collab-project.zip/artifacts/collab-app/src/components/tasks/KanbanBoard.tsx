import { useMemo, useState } from 'react';
import { 
  DndContext, 
  DragOverlay, 
  closestCorners, 
  KeyboardSensor, 
  PointerSensor, 
  useSensor, 
  useSensors,
  DragStartEvent,
  DragOverEvent,
  DragEndEvent
} from '@dnd-kit/core';
import { SortableContext, arrayMove, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { TaskWithDetails } from '@workspace/api-client-react';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Clock, MessageSquare, Paperclip, MoreHorizontal } from 'lucide-react';
import { format } from 'date-fns';
import { useUpdateTask } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';

const COLUMNS = [
  { id: 'TODO', title: 'To Do', color: 'bg-slate-100 dark:bg-slate-800/50 text-slate-800 dark:text-slate-300 border-t-4 border-t-slate-400' },
  { id: 'IN_PROGRESS', title: 'In Progress', color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 border-t-4 border-t-blue-500' },
  { id: 'IN_REVIEW', title: 'In Review', color: 'bg-purple-50 dark:bg-purple-900/20 text-purple-800 dark:text-purple-300 border-t-4 border-t-purple-500' },
  { id: 'DONE', title: 'Done', color: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-800 dark:text-emerald-300 border-t-4 border-t-emerald-500' }
];

function SortableTaskCard({ task, onClick }: { task: TaskWithDetails, onClick: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: task.id, data: { type: 'Task', task } });
  
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.3 : 1,
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style} 
      {...attributes} 
      {...listeners}
      onClick={onClick}
      className="bg-card p-3.5 rounded-xl border border-border shadow-sm hover:shadow-md hover:border-primary/30 transition-all cursor-grab active:cursor-grabbing mb-3 group"
    >
      <div className="flex justify-between items-start mb-2">
        <Badge variant={task.priority.toLowerCase() as any} className="text-[10px] px-1.5 py-0">
          {task.priority}
        </Badge>
        <button className="text-muted-foreground opacity-0 group-hover:opacity-100 hover:text-foreground transition-opacity">
          <MoreHorizontal className="w-4 h-4" />
        </button>
      </div>
      
      <h4 className="font-medium text-sm text-foreground mb-3 leading-snug">{task.title}</h4>
      
      <div className="flex items-center justify-between mt-auto">
        <div className="flex flex-col gap-2">
          {task.dueDate && (
            <div className={`flex items-center text-[10px] font-medium ${new Date(task.dueDate) < new Date() && task.status !== 'DONE' ? 'text-destructive' : 'text-muted-foreground'}`}>
              <Clock className="w-3 h-3 mr-1" />
              {format(new Date(task.dueDate), 'MMM d')}
            </div>
          )}
          <div className="flex items-center gap-2 text-muted-foreground text-[10px]">
            {task.commentCount > 0 && (
              <span className="flex items-center"><MessageSquare className="w-3 h-3 mr-1" />{task.commentCount}</span>
            )}
            {task.fileCount > 0 && (
              <span className="flex items-center"><Paperclip className="w-3 h-3 mr-1" />{task.fileCount}</span>
            )}
          </div>
        </div>
        
        <div className="flex -space-x-1.5">
          {task.assignees?.map(user => (
            <Avatar key={user.id} className="w-6 h-6 border-2 border-card">
              <AvatarImage src={user.avatarUrl || ''} />
              <AvatarFallback className="text-[10px] bg-primary/10 text-primary">{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
          ))}
        </div>
      </div>
    </div>
  );
}

export function KanbanBoard({ tasks, projectId, onTaskClick }: { tasks: TaskWithDetails[], projectId: number, onTaskClick: (task: TaskWithDetails) => void }) {
  const [activeTask, setActiveTask] = useState<TaskWithDetails | null>(null);
  const updateMutation = useUpdateTask();
  const queryClient = useQueryClient();

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const columns = useMemo(() => {
    const cols = { TODO: [], IN_PROGRESS: [], IN_REVIEW: [], DONE: [] } as Record<string, TaskWithDetails[]>;
    tasks.forEach(task => {
      if (cols[task.status]) cols[task.status].push(task);
    });
    return cols;
  }, [tasks]);

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    setActiveTask(active.data.current?.task);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveTask(null);

    if (!over) return;

    const activeId = active.id;
    const overId = over.id;
    
    // Find containers
    const activeTask = tasks.find(t => t.id === activeId);
    const overTask = tasks.find(t => t.id === overId);
    
    let overCol = over.data.current?.sortable?.containerId || over.id;
    if (overTask) overCol = overTask.status;

    if (!activeTask || activeTask.status === overCol) return;

    // Optimistic update
    queryClient.setQueryData([`/api/tasks`, { projectId }], (old: TaskWithDetails[] | undefined) => {
      if (!old) return old;
      return old.map(t => t.id === activeId ? { ...t, status: overCol } : t);
    });

    // Actual API call
    updateMutation.mutate({ 
      id: activeId as number, 
      data: { status: overCol as any } 
    });
  };

  return (
    <div className="flex h-full w-full gap-6 overflow-x-auto kanban-scroll pb-4">
      <DndContext 
        sensors={sensors} 
        collisionDetection={closestCorners} 
        onDragStart={handleDragStart} 
        onDragEnd={handleDragEnd}
      >
        {COLUMNS.map(col => (
          <div key={col.id} className="flex-shrink-0 w-80 flex flex-col bg-muted/30 rounded-xl overflow-hidden border border-border/50">
            <div className={`px-4 py-3 font-semibold flex items-center justify-between shadow-sm ${col.color}`}>
              <span className="font-display tracking-tight text-sm uppercase">{col.title}</span>
              <Badge variant="outline" className="bg-background/50 border-none">{columns[col.id].length}</Badge>
            </div>
            
            <div className="flex-1 p-3 overflow-y-auto kanban-scroll min-h-[200px]" id={col.id}>
              <SortableContext items={columns[col.id].map(t => t.id)} strategy={verticalListSortingStrategy} id={col.id}>
                {columns[col.id].map(task => (
                  <SortableTaskCard key={task.id} task={task} onClick={() => onTaskClick(task)} />
                ))}
              </SortableContext>
            </div>
          </div>
        ))}

        <DragOverlay>
          {activeTask ? (
            <div className="bg-card p-3.5 rounded-xl border-2 border-primary shadow-xl rotate-3 scale-105 cursor-grabbing opacity-90">
               <h4 className="font-medium text-sm text-foreground">{activeTask.title}</h4>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
    </div>
  );
}
