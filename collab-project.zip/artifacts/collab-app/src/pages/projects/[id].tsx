import { useState } from 'react';
import { useRoute } from 'wouter';
import { useGetProjectById, useGetTasks, TaskWithDetails } from '@workspace/api-client-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { format } from 'date-fns';
import { Calendar, Users, Target, FileText, ChevronLeft, Plus } from 'lucide-react';
import { Link } from 'wouter';
import { KanbanBoard } from '@/components/tasks/KanbanBoard';
import { Skeleton } from '@/components/ui/skeleton';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';

export default function ProjectDetail() {
  const [, params] = useRoute('/projects/:id');
  const projectId = parseInt(params?.id || '0', 10);
  
  const { data: project, isLoading: projLoading } = useGetProjectById(projectId);
  const { data: tasks, isLoading: tasksLoading } = useGetTasks({ projectId });
  
  const [selectedTask, setSelectedTask] = useState<TaskWithDetails | null>(null);

  if (projLoading) return <div className="p-8 space-y-6"><Skeleton className="h-20 w-full" /><Skeleton className="h-[500px] w-full" /></div>;
  if (!project) return <div>Project not found</div>;

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] animate-in fade-in duration-500">
      <div className="mb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <Link href="/projects" className="text-sm text-muted-foreground hover:text-foreground flex items-center mb-2 transition-colors">
            <ChevronLeft className="w-4 h-4 mr-1" /> Back to projects
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-display font-bold text-foreground">{project.name}</h1>
            <Badge variant={project.status.toLowerCase() as any} className="text-xs">{project.status.replace('_', ' ')}</Badge>
          </div>
          <p className="text-muted-foreground mt-1 max-w-2xl">{project.description}</p>
        </div>
        
        <div className="flex items-center gap-4 bg-card px-4 py-2 rounded-xl border border-border shadow-sm">
          <div className="text-sm">
            <div className="text-muted-foreground text-xs font-medium">Deadline</div>
            <div className="font-semibold">{project.deadline ? format(new Date(project.deadline), 'MMM d, yyyy') : 'None'}</div>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="flex -space-x-2">
            {project.members.slice(0, 3).map((m) => (
              <Avatar key={m.id} className="w-8 h-8 border-2 border-card">
                <AvatarImage src={m.avatarUrl || ''} />
                <AvatarFallback className="bg-primary/10 text-primary text-xs">{m.name.charAt(0)}</AvatarFallback>
              </Avatar>
            ))}
          </div>
        </div>
      </div>

      <Tabs defaultValue="board" className="flex-1 flex flex-col overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="board" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Target className="w-4 h-4 mr-2" /> Board
            </TabsTrigger>
            <TabsTrigger value="list" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <FileText className="w-4 h-4 mr-2" /> List
            </TabsTrigger>
            <TabsTrigger value="members" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Users className="w-4 h-4 mr-2" /> Members
            </TabsTrigger>
          </TabsList>
          
          <Button size="sm" className="shadow-md shadow-primary/20"><Plus className="w-4 h-4 mr-2" /> Add Task</Button>
        </div>

        <TabsContent value="board" className="flex-1 overflow-hidden m-0 border-0 p-0 focus-visible:ring-0">
          {tasksLoading ? (
            <div className="flex gap-6"><Skeleton className="w-80 h-[600px] rounded-xl" /><Skeleton className="w-80 h-[600px] rounded-xl" /></div>
          ) : (
            <KanbanBoard tasks={tasks || []} projectId={projectId} onTaskClick={setSelectedTask} />
          )}
        </TabsContent>
        
        {/* Placeholder for other tabs to show completeness of structure */}
        <TabsContent value="list">List view coming soon...</TabsContent>
        <TabsContent value="members">Members view coming soon...</TabsContent>
      </Tabs>

      {/* Task Detail Slide-over */}
      <Sheet open={!!selectedTask} onOpenChange={(o) => !o && setSelectedTask(null)}>
        <SheetContent className="w-full sm:max-w-md md:max-w-lg lg:max-w-xl overflow-y-auto">
          {selectedTask && (
            <>
              <SheetHeader className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant={selectedTask.priority.toLowerCase() as any}>{selectedTask.priority}</Badge>
                  <span className="text-xs font-medium text-muted-foreground">ID: #{selectedTask.id}</span>
                </div>
                <SheetTitle className="text-2xl font-display leading-tight">{selectedTask.title}</SheetTitle>
              </SheetHeader>
              
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4 bg-muted/30 p-4 rounded-xl border border-border">
                  <div>
                    <span className="text-xs text-muted-foreground font-medium block mb-1">Status</span>
                    <Badge variant={selectedTask.status.toLowerCase() as any}>{selectedTask.status.replace('_', ' ')}</Badge>
                  </div>
                  <div>
                    <span className="text-xs text-muted-foreground font-medium block mb-1">Due Date</span>
                    <span className="text-sm font-semibold">{selectedTask.dueDate ? format(new Date(selectedTask.dueDate), 'MMM d, yyyy') : 'No date'}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-xs text-muted-foreground font-medium block mb-2">Assignees</span>
                    <div className="flex gap-2">
                      {selectedTask.assignees?.map(u => (
                        <div key={u.id} className="flex items-center gap-2 bg-background border border-border px-2 py-1 rounded-md text-sm">
                          <Avatar className="w-5 h-5"><AvatarFallback className="text-[10px]">{u.name.charAt(0)}</AvatarFallback></Avatar>
                          {u.name}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-semibold mb-2">Description</h4>
                  <div className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap bg-card p-4 rounded-xl border border-border">
                    {selectedTask.description || <span className="italic opacity-50">No description provided.</span>}
                  </div>
                </div>

                {/* Subtasks, Comments etc would go here */}
                <div>
                  <h4 className="text-sm font-semibold mb-3 border-b border-border pb-2">Activity Thread</h4>
                  <div className="text-center py-8 text-sm text-muted-foreground border-2 border-dashed border-border rounded-xl">
                    <MessageSquare className="w-6 h-6 mx-auto mb-2 opacity-50" />
                    Activity feed functionality
                  </div>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
