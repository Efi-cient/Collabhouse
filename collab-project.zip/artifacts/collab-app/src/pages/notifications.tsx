import { useGetNotifications, useMarkAllNotificationsRead, useMarkNotificationRead } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Bell, CheckCheck, FolderKanban, MessageSquare, User, Clock, CheckCircle2, AlertTriangle, AtSign } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { getGetNotificationsQueryKey } from '@workspace/api-client-react';

const typeConfig: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  TASK_ASSIGNED: { icon: User, color: 'text-blue-500', label: 'Task Assigned' },
  TASK_DUE_SOON: { icon: Clock, color: 'text-yellow-500', label: 'Due Soon' },
  TASK_COMPLETED: { icon: CheckCircle2, color: 'text-green-500', label: 'Task Completed' },
  MILESTONE_DUE: { icon: AlertTriangle, color: 'text-orange-500', label: 'Milestone Due' },
  MENTIONED: { icon: AtSign, color: 'text-purple-500', label: 'Mentioned' },
  MESSAGE_RECEIVED: { icon: MessageSquare, color: 'text-blue-500', label: 'New Message' },
  GROUP_MESSAGE: { icon: MessageSquare, color: 'text-indigo-500', label: 'Group Message' },
  PROJECT_UPDATED: { icon: FolderKanban, color: 'text-teal-500', label: 'Project Updated' },
};

export default function NotificationsPage() {
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();

  const { data: notifications, isLoading } = useGetNotifications({ limit: 100 });
  const markAllRead = useMarkAllNotificationsRead({
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: getGetNotificationsQueryKey() });
    },
  });
  const markRead = useMarkNotificationRead({
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: getGetNotificationsQueryKey() });
    },
  });

  const unreadCount = notifications?.filter(n => !n.isRead).length ?? 0;

  function handleNotificationClick(notif: { id: number; isRead: boolean; resourceType?: string | null; resourceId?: number | null }) {
    if (!notif.isRead) {
      markRead.mutate({ id: notif.id });
    }
    if (notif.resourceType === 'task' && notif.resourceId) {
      navigate(`/projects`);
    } else if (notif.resourceType === 'conversation' && notif.resourceId) {
      navigate(`/messages`);
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Notifications</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}` : 'All caught up!'}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => markAllRead.mutate({})}
            disabled={markAllRead.isPending}
            data-testid="button-mark-all-read"
          >
            <CheckCheck className="w-4 h-4 mr-2" />
            Mark all read
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-lg" />
          ))}
        </div>
      ) : notifications?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <Bell className="w-16 h-16 text-muted-foreground/30 mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-1">No notifications</h3>
          <p className="text-sm text-muted-foreground">You're all caught up! Check back later.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications?.map((notif) => {
            const config = typeConfig[notif.type] ?? { icon: Bell, color: 'text-muted-foreground', label: notif.type };
            const Icon = config.icon;

            return (
              <Card
                key={notif.id}
                className={`cursor-pointer transition-all hover:shadow-md ${!notif.isRead ? 'border-primary/30 bg-primary/5' : ''}`}
                onClick={() => handleNotificationClick(notif)}
                data-testid={`notification-item-${notif.id}`}
              >
                <CardContent className="p-4 flex items-start gap-4">
                  <div className={`mt-0.5 shrink-0 ${config.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className={`text-sm font-medium ${!notif.isRead ? 'text-foreground' : 'text-muted-foreground'}`}>
                          {notif.title}
                        </p>
                        <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">{notif.body}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {!notif.isRead && (
                          <div className="w-2 h-2 rounded-full bg-primary shrink-0" />
                        )}
                        <Badge variant="secondary" className="text-xs whitespace-nowrap">
                          {config.label}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {formatDistanceToNow(new Date(notif.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
