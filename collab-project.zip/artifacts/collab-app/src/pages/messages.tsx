import { useState } from 'react';
import { 
  useGetConversations, 
  useGetMessages, 
  useSendMessage,
  ConversationWithDetails,
  MessageWithDetails
} from '@workspace/api-client-react';
import { useAuthStore } from '@/lib/auth-store';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Send, Hash, Paperclip, Smile, Edit2, Reply } from 'lucide-react';
import { format } from 'date-fns';

export default function Messages() {
  const { user } = useAuthStore();
  const { data: convos, isLoading: convosLoading } = useGetConversations();
  const [activeConvoId, setActiveConvoId] = useState<number | null>(null);

  const activeConvo = convos?.find(c => c.id === activeConvoId);

  return (
    <div className="flex h-[calc(100vh-8rem)] bg-card border border-border rounded-2xl overflow-hidden shadow-sm animate-in fade-in zoom-in-95 duration-300">
      {/* Sidebar */}
      <div className="w-80 border-r border-border flex flex-col bg-muted/10">
        <div className="p-4 border-b border-border">
          <h2 className="text-xl font-display font-bold mb-4">Messages</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search chats..." className="pl-9 bg-background" />
          </div>
        </div>
        <ScrollArea className="flex-1">
          {convosLoading ? (
             <div className="p-4 space-y-4">
               {[1,2,3,4].map(i => <div key={i} className="h-16 bg-muted animate-pulse rounded-xl" />)}
             </div>
          ) : (
            <div className="p-2 space-y-1">
              {convos?.map(convo => {
                const otherMember = convo.members.find(m => m.userId !== user?.id)?.user;
                const isGroup = convo.type === 'GROUP';
                const name = isGroup ? convo.name : otherMember?.name;
                const initials = name?.substring(0, 2).toUpperCase() || '??';
                const isActive = convo.id === activeConvoId;

                return (
                  <button
                    key={convo.id}
                    onClick={() => setActiveConvoId(convo.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all ${
                      isActive ? 'bg-primary text-primary-foreground shadow-md' : 'hover:bg-muted/50 text-foreground'
                    }`}
                  >
                    <Avatar className={`w-12 h-12 border-2 ${isActive ? 'border-primary-foreground/20' : 'border-background'}`}>
                      {isGroup ? (
                        <AvatarFallback className={isActive ? 'bg-primary-foreground/20' : 'bg-primary/10 text-primary'}><Hash className="w-5 h-5" /></AvatarFallback>
                      ) : (
                        <>
                          <AvatarImage src={otherMember?.avatarUrl || ''} />
                          <AvatarFallback className={isActive ? 'bg-primary-foreground/20' : 'bg-primary/10 text-primary'}>{initials}</AvatarFallback>
                        </>
                      )}
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline mb-1">
                        <span className="font-semibold truncate">{name}</span>
                        {convo.lastMessage && (
                          <span className={`text-[10px] ${isActive ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                            {format(new Date(convo.lastMessage.createdAt), 'h:mm a')}
                          </span>
                        )}
                      </div>
                      <p className={`text-sm truncate ${isActive ? 'text-primary-foreground/90' : 'text-muted-foreground'}`}>
                        {convo.lastMessage?.content || <span className="italic">No messages yet</span>}
                      </p>
                    </div>
                    {convo.unreadCount > 0 && !isActive && (
                      <div className="w-5 h-5 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center">
                        {convo.unreadCount}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-background">
        {activeConvo ? (
          <ChatWindow convoId={activeConvo.id} convo={activeConvo} />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
            <MessageSquare className="w-16 h-16 mb-4 opacity-20" />
            <p className="text-lg font-medium text-foreground/50">Select a conversation</p>
            <p className="text-sm">Choose a chat from the sidebar to start messaging</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ChatWindow({ convoId, convo }: { convoId: number, convo: ConversationWithDetails }) {
  const { user } = useAuthStore();
  const { data: messages, isLoading } = useGetMessages(convoId);
  const sendMutation = useSendMessage();
  const [input, setInput] = useState('');

  const isGroup = convo.type === 'GROUP';
  const otherMember = convo.members.find(m => m.userId !== user?.id)?.user;
  const name = isGroup ? convo.name : otherMember?.name;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    sendMutation.mutate({ id: convoId, data: { content: input } }, {
      onSuccess: () => setInput('')
    });
  };

  return (
    <>
      <div className="h-16 px-6 border-b border-border flex items-center justify-between bg-card shrink-0">
        <div className="flex items-center gap-3">
          <Avatar className="w-10 h-10 border-2 border-background shadow-sm">
            {isGroup ? <AvatarFallback className="bg-primary/10 text-primary"><Hash className="w-4 h-4" /></AvatarFallback> : (
              <><AvatarImage src={otherMember?.avatarUrl || ''} /><AvatarFallback className="bg-primary/10 text-primary">{name?.charAt(0)}</AvatarFallback></>
            )}
          </Avatar>
          <div>
            <h3 className="font-semibold text-foreground">{name}</h3>
            <p className="text-xs text-muted-foreground">
              {isGroup ? `${convo.members.length} members` : 'Online'}
            </p>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1 p-6">
        {isLoading ? (
          <div className="space-y-4">
             {[1,2,3].map(i => <div key={i} className="h-20 bg-muted/50 animate-pulse rounded-xl w-3/4" />)}
          </div>
        ) : (
          <div className="space-y-6 flex flex-col justify-end min-h-full">
            {messages?.slice().reverse().map(msg => {
              const isMe = msg.senderId === user?.id;
              return (
                <div key={msg.id} className={`flex gap-3 max-w-[80%] ${isMe ? 'ml-auto flex-row-reverse' : ''}`}>
                  <Avatar className="w-8 h-8 shrink-0 border border-border mt-auto">
                    <AvatarImage src={msg.sender.avatarUrl || ''} />
                    <AvatarFallback className="text-[10px]">{msg.sender.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                    {!isMe && isGroup && <span className="text-xs text-muted-foreground ml-1 mb-1 font-medium">{msg.sender.name}</span>}
                    <div className={`px-4 py-2.5 rounded-2xl ${
                      isMe 
                        ? 'bg-primary text-primary-foreground rounded-br-sm shadow-md shadow-primary/20' 
                        : 'bg-muted text-foreground rounded-bl-sm border border-border shadow-sm'
                    }`}>
                      <p className="text-sm leading-relaxed">{msg.content}</p>
                    </div>
                    <span className="text-[10px] text-muted-foreground mt-1 mx-1">
                      {format(new Date(msg.createdAt), 'h:mm a')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>

      <div className="p-4 bg-card border-t border-border shrink-0">
        <form onSubmit={handleSend} className="flex items-end gap-2 bg-muted/50 border border-border rounded-xl p-2 focus-within:ring-2 focus-within:ring-primary/20 focus-within:border-primary/50 transition-all">
          <Button type="button" variant="ghost" size="icon" className="shrink-0 text-muted-foreground hover:text-foreground">
            <Paperclip className="w-5 h-5" />
          </Button>
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..." 
            className="flex-1 bg-transparent border-none focus:outline-none min-h-[40px] max-h-32 py-2 text-sm resize-none"
          />
          <Button type="button" variant="ghost" size="icon" className="shrink-0 text-muted-foreground hover:text-foreground">
            <Smile className="w-5 h-5" />
          </Button>
          <Button type="submit" size="icon" className="shrink-0 bg-primary hover:bg-primary/90 text-primary-foreground shadow-md transition-transform active:scale-95" disabled={!input.trim() || sendMutation.isPending}>
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </>
  );
}
