import { useAuthStore } from '@/lib/auth-store';
import { 
  useGetAdminDashboard, 
  useGetPmDashboard, 
  useGetMemberDashboard, 
  useGetSupervisorDashboard 
} from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Users, FolderKanban, CheckCircle2, AlertTriangle, Clock, Activity, MessageSquare } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

export default function Dashboard() {
  const { user } = useAuthStore();

  if (!user) return null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-display font-bold tracking-tight text-foreground">Welcome back, {user.name.split(' ')[0]}</h2>
        <p className="text-muted-foreground mt-1">Here's what's happening in your workspace today.</p>
      </div>

      {user.role === 'ADMIN' && <AdminDashboardView />}
      {user.role === 'PROJECT_MANAGER' && <PmDashboardView />}
      {user.role === 'TEAM_MEMBER' && <MemberDashboardView />}
      {user.role === 'SUPERVISOR' && <SupervisorDashboardView />}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, description }: { title: string, value: string | number, icon: any, description?: string }) {
  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="w-5 h-5 text-primary opacity-80" />
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-display font-bold text-foreground">{value}</div>
        {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
      </CardContent>
    </Card>
  );
}

function AdminDashboardView() {
  const { data, isLoading } = useGetAdminDashboard();

  if (isLoading) return <DashboardSkeleton />;
  if (!data) return null;

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Total Users" value={data.totalUsers} icon={Users} description="Active accounts in system" />
        <StatCard title="Active Projects" value={data.activeProjects} icon={FolderKanban} description="Currently in progress" />
        <StatCard title="Tasks Created" value={data.tasksCreatedThisMonth} icon={CheckCircle2} description="This month" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4 shadow-sm">
          <CardHeader>
            <CardTitle>Task Completion by Project</CardTitle>
            <CardDescription>Overview of progress across active projects</CardDescription>
          </CardHeader>
          <CardContent className="pl-0 h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.tasksByProject} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis dataKey="projectName" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <Tooltip cursor={{ fill: 'rgba(0,0,0,0.05)' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="total" name="Total Tasks" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="completed" name="Completed" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="col-span-3 shadow-sm flex flex-col">
          <CardHeader>
            <CardTitle>System Activity</CardTitle>
            <CardDescription>Latest actions across all projects</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto pr-2">
            <div className="space-y-4">
              {data.recentActivity.map(activity => (
                <div key={activity.id} className="flex items-start gap-3 text-sm">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                    <Activity className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-foreground"><span className="font-semibold">{activity.user.name}</span> {activity.eventType.replace('_', ' ').toLowerCase()}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{format(new Date(activity.createdAt), 'MMM d, h:mm a')}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function PmDashboardView() {
  const { data, isLoading } = useGetPmDashboard();

  if (isLoading) return <DashboardSkeleton />;
  if (!data) return null;

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="My Projects" value={data.myProjects.length} icon={FolderKanban} />
        <StatCard title="Overdue Tasks" value={data.overdueTasks.length} icon={AlertTriangle} description="Needs immediate attention" />
        <StatCard title="Upcoming Milestones" value={data.upcomingMilestones.length} icon={CheckCircle2} description="Next 14 days" />
        <StatCard title="Team Members" value={data.teamWorkload.length} icon={Users} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Team Workload</CardTitle>
            <CardDescription>Active tasks per member</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.teamWorkload} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#e5e7eb" />
                <XAxis type="number" axisLine={false} tickLine={false} />
                <YAxis dataKey="userName" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} width={100} />
                <Tooltip cursor={{ fill: 'rgba(0,0,0,0.05)' }} contentStyle={{ borderRadius: '8px', border: 'none' }} />
                <Bar dataKey="taskCount" name="Tasks" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Overdue Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.overdueTasks.slice(0, 5).map(task => (
                <div key={task.id} className="flex items-center justify-between p-3 rounded-lg border border-destructive/20 bg-destructive/5">
                  <div className="flex-1 min-w-0 pr-4">
                    <p className="font-medium text-sm text-foreground truncate">{task.title}</p>
                    <p className="text-xs text-destructive mt-1 flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      Due {format(new Date(task.dueDate!), 'MMM d')}
                    </p>
                  </div>
                  <Badge variant="destructive" className="shrink-0">{task.priority}</Badge>
                </div>
              ))}
              {data.overdueTasks.length === 0 && (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2 opacity-50" />
                  No overdue tasks!
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function MemberDashboardView() {
  const { data, isLoading } = useGetMemberDashboard();

  if (isLoading) return <DashboardSkeleton />;
  if (!data) return null;

  const COLORS = ['#94a3b8', '#3b82f6', '#f59e0b', '#10b981'];

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Tasks Due Today" value={data.myTasksToday.length} icon={CheckCircle2} />
        <StatCard title="Unread Messages" value={data.unreadMessagesCount} icon={MessageSquare} />
        <StatCard title="Recent Comments" value={data.recentComments.length} icon={Activity} />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="col-span-2 shadow-sm">
          <CardHeader>
            <CardTitle>My Tasks Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.myTasksToday.map(task => (
                <div key={task.id} className="flex items-center justify-between p-4 rounded-xl border border-border bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div>
                    <h4 className="font-medium text-foreground">{task.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{task.projectId} • Due {format(new Date(task.dueDate!), 'h:mm a')}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={task.priority.toLowerCase() as any}>{task.priority}</Badge>
                    <Badge variant={task.status.toLowerCase() as any}>{task.status.replace('_', ' ')}</Badge>
                  </div>
                </div>
              ))}
              {data.myTasksToday.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  You're all caught up for today!
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Task Status</CardTitle>
          </CardHeader>
          <CardContent className="h-[250px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.taskStatusBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="count"
                  nameKey="status"
                >
                  {data.taskStatusBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function SupervisorDashboardView() {
  const { data, isLoading } = useGetSupervisorDashboard();

  if (isLoading) return <DashboardSkeleton />;
  if (!data) return null;

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Projects On Track" value={data.healthSummary.onTrack} icon={CheckCircle2} />
        <StatCard title="Projects At Risk" value={data.healthSummary.atRisk} icon={AlertTriangle} />
        <StatCard title="Projects Overdue" value={data.healthSummary.overdue} icon={Clock} />
      </div>

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Project Portfolio</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data.projectSummaries.map(project => (
              <div key={project.id} className="flex items-center justify-between p-4 rounded-xl border border-border bg-card">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <h4 className="font-semibold text-foreground">{project.name}</h4>
                    <Badge variant={project.status.toLowerCase() as any}>{project.status}</Badge>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                    <span>{project.completedTasks} / {project.totalTasks} Tasks</span>
                    <span>•</span>
                    <span>Deadline: {project.deadline ? format(new Date(project.deadline), 'MMM d, yyyy') : 'No deadline'}</span>
                  </div>
                </div>
                <div className="w-32">
                  <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary transition-all duration-500" 
                      style={{ width: `${project.totalTasks > 0 ? (project.completedTasks / project.totalTasks) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-3">
        {[1, 2, 3].map(i => (
          <Card key={i}>
            <CardHeader className="pb-2"><Skeleton className="h-4 w-24" /></CardHeader>
            <CardContent><Skeleton className="h-8 w-16" /></CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Skeleton className="h-[400px] w-full rounded-xl" />
        <Skeleton className="h-[400px] w-full rounded-xl" />
      </div>
    </div>
  );
}
