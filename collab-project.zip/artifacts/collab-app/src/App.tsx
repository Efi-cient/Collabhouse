import { Switch, Route, Router as WouterRouter, Redirect, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuthStore } from "@/lib/auth-store";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEffect } from "react";

// Pages
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import ProjectsList from "@/pages/projects/index";
import ProjectDetail from "@/pages/projects/[id]";
import Messages from "@/pages/messages";
import UsersManagement from "@/pages/users";
import NotificationsPage from "@/pages/notifications";

// --- GLOBAL FETCH PATCH FOR AUTH ---
// Automatically injects the JWT token into all /api requests
const originalFetch = window.fetch;
window.fetch = async (input, init) => {
  const token = localStorage.getItem('auth_token');
  if (token && typeof input === 'string' && input.startsWith('/api')) {
    init = init || {};
    init.headers = {
      ...init.headers,
      Authorization: `Bearer ${token}`
    };
    init.credentials = "include"; // Ensure cookies are also sent if hybrid auth exists
  }
  return originalFetch(input, init);
};

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function ProtectedRoute({ component: Component, ...rest }: { component: any, path: string }) {
  const { isAuthenticated } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }
  
  return (
    <AppLayout>
      <Component {...rest} />
    </AppLayout>
  );
}

function Router() {
  const { isAuthenticated } = useAuthStore();
  const [location] = useLocation();

  // Root redirect logic
  if (location === '/') {
    return <Redirect to={isAuthenticated ? "/dashboard" : "/login"} />;
  }

  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      {/* Protected Routes inside AppLayout */}
      <Route path="/dashboard"><ProtectedRoute component={Dashboard} path="/dashboard" /></Route>
      <Route path="/projects"><ProtectedRoute component={ProjectsList} path="/projects" /></Route>
      <Route path="/projects/:id"><ProtectedRoute component={ProjectDetail} path="/projects/:id" /></Route>
      <Route path="/messages"><ProtectedRoute component={Messages} path="/messages" /></Route>
      <Route path="/users"><ProtectedRoute component={UsersManagement} path="/users" /></Route>
      
      <Route path="/notifications"><ProtectedRoute component={NotificationsPage} path="/notifications" /></Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
