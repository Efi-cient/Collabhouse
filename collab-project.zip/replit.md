# CollabSync - Integrated Project Collaboration System

## Overview

A full-stack, production-ready Project Collaboration and Progress Management System built with React + Vite (frontend) and Express + PostgreSQL (backend) in a pnpm monorepo.

## Credentials (Seed Data)

All users share the password: **`Password123!`**

| Role           | Email                   |
|----------------|-------------------------|
| Admin          | admin@example.com       |
| Project Mgr 1  | pm1@example.com         |
| Project Mgr 2  | pm2@example.com         |
| Team Member 1  | member1@example.com     |
| Team Member 2  | member2@example.com     |
| Team Member 3  | member3@example.com     |
| Team Member 4  | member4@example.com     |
| Supervisor     | supervisor@example.com  |

## Features

- **Role-based access**: Admin, Project Manager, Team Member, Supervisor
- **Role-aware dashboards**: Each role sees relevant stats and charts
- **Project management**: Create/edit projects, assign members, track status
- **Task management**: Kanban board with drag-and-drop (@dnd-kit), subtasks, comments, file attachments, activity logs
- **Milestones**: Per-project milestone tracking with due dates
- **Real-time messaging**: DMs + group conversations, message reactions, pinned messages
- **Notifications**: In-app notifications with read/unread state
- **User management**: Admin-only user CRUD
- **Reports**: Project progress reports with charts (Recharts)
- **JWT authentication**: Token stored in localStorage, auto-injected in all API calls

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React 19, Vite 7, Wouter (routing), TanStack Query, Zustand, shadcn/ui, Tailwind CSS
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod, drizzle-zod
- **API codegen**: Orval (from OpenAPI spec → React Query hooks + Zod schemas)
- **Build**: esbuild (API bundle), Vite (frontend)
- **Charts**: Recharts
- **Real-time**: Pusher (server-side `pusher`, client-side `pusher-js`)

## Structure

```text
artifacts-monorepo/
├── artifacts/
│   ├── api-server/          # Express API server (port 8080)
│   └── collab-app/          # React + Vite frontend (port from $PORT)
├── lib/
│   ├── api-spec/            # OpenAPI spec + Orval codegen config
│   ├── api-client-react/    # Generated React Query hooks + fetch client
│   ├── api-zod/             # Generated Zod schemas from OpenAPI
│   └── db/                  # Drizzle ORM schema + DB connection
├── scripts/
│   └── src/seed.ts          # Database seed script
└── pnpm-workspace.yaml
```

## API Routes

All routes prefixed with `/api`:
- `POST /api/auth/register` — register new user
- `POST /api/auth/login` — login, returns JWT
- `GET  /api/auth/me` — current user
- `POST /api/auth/logout` — logout
- `GET/POST /api/users` — list/create users (admin)
- `GET/PUT/DELETE /api/users/:id` — user CRUD
- `GET/POST /api/projects` — list/create projects
- `GET/PUT/DELETE /api/projects/:id` — project CRUD
- `GET/POST /api/projects/:id/members` — project members
- `GET/POST /api/projects/:id/milestones` — milestones
- `GET/POST /api/projects/:id/tasks` — tasks
- `GET/PUT/DELETE /api/tasks/:id` — task CRUD
- `POST /api/tasks/:id/subtasks` — subtasks
- `GET/POST /api/tasks/:id/comments` — comments
- `GET/POST /api/tasks/:id/files` — file attachments
- `GET/POST /api/conversations` — conversations
- `GET/POST /api/conversations/:id/messages` — messages
- `GET/PUT /api/notifications` — notifications
- `GET /api/dashboard/admin|pm|member|supervisor` — role dashboards
- `GET /api/reports/project/:id` — project report
- `POST /api/pusher/auth` — Pusher channel auth

## Frontend Pages

- `/login` — Login page with split-panel design
- `/register` — Registration page
- `/dashboard` — Role-aware dashboard with stats + charts
- `/projects` — Projects list with filters
- `/projects/:id` — Project detail with Kanban board, milestones, members
- `/messages` — Real-time messaging (DMs + groups)
- `/notifications` — Notification inbox with read/unread state
- `/users` — User management (admin-only)

## TypeScript & Composite Projects

- All packages extend `tsconfig.base.json` (composite: true)
- Run `pnpm run typecheck` from root for full build
- API codegen: `pnpm --filter @workspace/api-spec run codegen`
- DB push: `pnpm --filter @workspace/db run push`
- Seed DB: `pnpm --filter @workspace/scripts run seed`

## Auth Notes

- JWT stored in `localStorage` as `auth_token` and `auth_user`
- All `/api` fetch requests automatically have Bearer token injected (global fetch patch in App.tsx)
- Backend uses `SESSION_SECRET` env var for JWT signing
- Pusher env vars: `VITE_PUSHER_KEY`, `VITE_PUSHER_CLUSTER`
