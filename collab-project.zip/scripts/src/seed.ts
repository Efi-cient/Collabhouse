import bcrypt from "bcrypt";
import { db } from "@workspace/db";
import {
  usersTable,
  projectsTable,
  projectMembersTable,
  milestonesTable,
  tasksTable,
  taskAssigneesTable,
  subTasksTable,
  commentsTable,
  activityLogsTable,
  conversationsTable,
  conversationMembersTable,
  messagesTable,
  notificationsTable,
} from "@workspace/db";

async function seed() {
  console.log("🌱 Seeding database...");

  // Hash password (same for all demo users)
  const passwordHash = await bcrypt.hash("Password123!", 12);

  // Create users
  const [admin] = await db
    .insert(usersTable)
    .values({
      name: "Alice Admin",
      email: "admin@example.com",
      passwordHash,
      role: "ADMIN",
      isActive: true,
    })
    .returning();

  const [pm1] = await db
    .insert(usersTable)
    .values({
      name: "Bob Manager",
      email: "pm1@example.com",
      passwordHash,
      role: "PROJECT_MANAGER",
      isActive: true,
    })
    .returning();

  const [pm2] = await db
    .insert(usersTable)
    .values({
      name: "Carol Director",
      email: "pm2@example.com",
      passwordHash,
      role: "PROJECT_MANAGER",
      isActive: true,
    })
    .returning();

  const [member1] = await db
    .insert(usersTable)
    .values({
      name: "David Dev",
      email: "member1@example.com",
      passwordHash,
      role: "TEAM_MEMBER",
      isActive: true,
    })
    .returning();

  const [member2] = await db
    .insert(usersTable)
    .values({
      name: "Eva Engineer",
      email: "member2@example.com",
      passwordHash,
      role: "TEAM_MEMBER",
      isActive: true,
    })
    .returning();

  const [member3] = await db
    .insert(usersTable)
    .values({
      name: "Frank Frontend",
      email: "member3@example.com",
      passwordHash,
      role: "TEAM_MEMBER",
      isActive: true,
    })
    .returning();

  const [member4] = await db
    .insert(usersTable)
    .values({
      name: "Grace Backend",
      email: "member4@example.com",
      passwordHash,
      role: "TEAM_MEMBER",
      isActive: true,
    })
    .returning();

  const [supervisor] = await db
    .insert(usersTable)
    .values({
      name: "Henry Supervisor",
      email: "supervisor@example.com",
      passwordHash,
      role: "SUPERVISOR",
      isActive: true,
    })
    .returning();

  if (!admin || !pm1 || !pm2 || !member1 || !member2 || !member3 || !member4 || !supervisor) {
    throw new Error("Failed to create users");
  }

  console.log("✅ Users created");

  // Create projects
  const [activeProject] = await db
    .insert(projectsTable)
    .values({
      name: "Phoenix Platform",
      description: "Next-generation SaaS platform rebuild with modern architecture.",
      status: "ACTIVE",
      startDate: new Date("2026-01-15"),
      deadline: new Date("2026-06-30"),
      createdById: pm1.id,
    })
    .returning();

  const [onHoldProject] = await db
    .insert(projectsTable)
    .values({
      name: "Mobile App v2",
      description: "Major redesign and feature update for iOS and Android apps.",
      status: "ON_HOLD",
      startDate: new Date("2026-02-01"),
      deadline: new Date("2026-08-15"),
      createdById: pm2.id,
    })
    .returning();

  const [completedProject] = await db
    .insert(projectsTable)
    .values({
      name: "API Gateway Migration",
      description: "Migrated all microservices to unified API gateway.",
      status: "COMPLETED",
      startDate: new Date("2025-10-01"),
      deadline: new Date("2026-01-31"),
      createdById: pm1.id,
    })
    .returning();

  if (!activeProject || !onHoldProject || !completedProject) {
    throw new Error("Failed to create projects");
  }

  console.log("✅ Projects created");

  // Project members
  await db.insert(projectMembersTable).values([
    { projectId: activeProject.id, userId: pm1.id },
    { projectId: activeProject.id, userId: member1.id },
    { projectId: activeProject.id, userId: member2.id },
    { projectId: activeProject.id, userId: member3.id },
    { projectId: activeProject.id, userId: member4.id },
    { projectId: activeProject.id, userId: supervisor.id },
    { projectId: onHoldProject.id, userId: pm2.id },
    { projectId: onHoldProject.id, userId: member2.id },
    { projectId: onHoldProject.id, userId: member3.id },
    { projectId: completedProject.id, userId: pm1.id },
    { projectId: completedProject.id, userId: member1.id },
    { projectId: completedProject.id, userId: member4.id },
  ]);

  console.log("✅ Project members assigned");

  // Milestones
  await db.insert(milestonesTable).values([
    {
      projectId: activeProject.id,
      title: "Architecture Design Complete",
      targetDate: new Date("2026-02-28"),
      isCompleted: true,
    },
    {
      projectId: activeProject.id,
      title: "Core API Development",
      targetDate: new Date("2026-04-15"),
      isCompleted: false,
    },
    {
      projectId: activeProject.id,
      title: "Beta Launch",
      targetDate: new Date("2026-05-31"),
      isCompleted: false,
    },
    {
      projectId: onHoldProject.id,
      title: "UI/UX Design Mockups",
      targetDate: new Date("2026-03-31"),
      isCompleted: false,
    },
    {
      projectId: completedProject.id,
      title: "Gateway Configuration",
      targetDate: new Date("2025-11-30"),
      isCompleted: true,
    },
    {
      projectId: completedProject.id,
      title: "Service Migration Complete",
      targetDate: new Date("2026-01-15"),
      isCompleted: true,
    },
  ]);

  console.log("✅ Milestones created");

  // Tasks for active project
  const [task1] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "Set up CI/CD pipeline",
      description: "Configure GitHub Actions for automated testing and deployment.",
      status: "DONE",
      priority: "HIGH",
      dueDate: new Date("2026-02-20"),
      estimatedHours: 8,
      createdById: pm1.id,
    })
    .returning();

  const [task2] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "Design database schema",
      description: "Create comprehensive ERD and implement Drizzle schema for all entities.",
      status: "DONE",
      priority: "CRITICAL",
      dueDate: new Date("2026-02-25"),
      estimatedHours: 16,
      createdById: pm1.id,
    })
    .returning();

  const [task3] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "Implement authentication service",
      description: "JWT-based auth with refresh tokens, password hashing, and session management.",
      status: "IN_PROGRESS",
      priority: "CRITICAL",
      dueDate: new Date("2026-04-10"),
      estimatedHours: 24,
      createdById: pm1.id,
    })
    .returning();

  const [task4] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "Build user dashboard",
      description: "Create responsive dashboard with analytics and activity feed.",
      status: "IN_PROGRESS",
      priority: "HIGH",
      dueDate: new Date("2026-04-20"),
      estimatedHours: 20,
      createdById: pm1.id,
    })
    .returning();

  const [task5] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "API documentation",
      description: "Write OpenAPI spec and developer documentation.",
      status: "TODO",
      priority: "MEDIUM",
      dueDate: new Date("2026-05-01"),
      estimatedHours: 12,
      createdById: pm1.id,
    })
    .returning();

  const [task6] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "Performance optimization",
      description: "Profile and optimize database queries, add Redis caching.",
      status: "TODO",
      priority: "HIGH",
      dueDate: new Date("2026-05-15"),
      estimatedHours: 16,
      createdById: pm1.id,
    })
    .returning();

  const [task7] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "Security audit",
      description: "Conduct security audit and fix vulnerabilities.",
      status: "IN_REVIEW",
      priority: "CRITICAL",
      dueDate: new Date("2026-04-05"),
      estimatedHours: 20,
      createdById: pm1.id,
    })
    .returning();

  // Overdue task
  const [task8] = await db
    .insert(tasksTable)
    .values({
      projectId: activeProject.id,
      title: "Write unit tests",
      description: "Achieve 80% code coverage across all modules.",
      status: "TODO",
      priority: "HIGH",
      dueDate: new Date("2026-03-01"), // Past date
      estimatedHours: 32,
      createdById: pm1.id,
    })
    .returning();

  if (!task1 || !task2 || !task3 || !task4 || !task5 || !task6 || !task7 || !task8) {
    throw new Error("Failed to create tasks");
  }

  // Assign tasks
  await db.insert(taskAssigneesTable).values([
    { taskId: task1.id, userId: member4.id },
    { taskId: task2.id, userId: member1.id },
    { taskId: task2.id, userId: member4.id },
    { taskId: task3.id, userId: member1.id },
    { taskId: task4.id, userId: member3.id },
    { taskId: task5.id, userId: member2.id },
    { taskId: task6.id, userId: member4.id },
    { taskId: task7.id, userId: member1.id },
    { taskId: task7.id, userId: member2.id },
    { taskId: task8.id, userId: member3.id },
  ]);

  // Subtasks
  await db.insert(subTasksTable).values([
    { taskId: task3.id, title: "Set up JWT middleware", isCompleted: true },
    { taskId: task3.id, title: "Implement refresh token rotation", isCompleted: false },
    { taskId: task3.id, title: "Add rate limiting", isCompleted: false },
    { taskId: task4.id, title: "Create chart components", isCompleted: true },
    { taskId: task4.id, title: "Add activity feed widget", isCompleted: false },
    { taskId: task4.id, title: "Mobile responsive layout", isCompleted: false },
  ]);

  // Comments
  const [comment1] = await db
    .insert(commentsTable)
    .values({
      taskId: task3.id,
      userId: pm1.id,
      content: "Great progress! Can you estimate when the refresh token implementation will be done?",
    })
    .returning();

  const [comment2] = await db
    .insert(commentsTable)
    .values({
      taskId: task3.id,
      userId: member1.id,
      content: "Should be done by end of week. I'm following OWASP recommendations for token security.",
    })
    .returning();

  await db.insert(commentsTable).values({
    taskId: task3.id,
    userId: member1.id,
    content: "Just a quick note: we should consider @member2 for a security review once this is done.",
    parentId: comment1!.id,
  });

  await db.insert(commentsTable).values({
    taskId: task7.id,
    userId: member2.id,
    content: "Found two medium-severity issues in the input validation layer. Documenting them now.",
  });

  // Activity logs
  await db.insert(activityLogsTable).values([
    { taskId: task1.id, userId: member4.id, eventType: "STATUS_CHANGED", metadata: { status: "DONE" } },
    { taskId: task2.id, userId: member1.id, eventType: "STATUS_CHANGED", metadata: { status: "DONE" } },
    { taskId: task3.id, userId: pm1.id, eventType: "TASK_CREATED", metadata: { title: task3.title } },
    { taskId: task3.id, userId: member1.id, eventType: "STATUS_CHANGED", metadata: { status: "IN_PROGRESS" } },
    { taskId: task3.id, userId: pm1.id, eventType: "COMMENT_ADDED", metadata: { commentId: comment1!.id } },
    { taskId: task4.id, userId: pm1.id, eventType: "TASK_CREATED", metadata: { title: task4.title } },
    { taskId: task7.id, userId: pm1.id, eventType: "TASK_CREATED", metadata: { title: task7.title } },
    { taskId: task7.id, userId: member2.id, eventType: "STATUS_CHANGED", metadata: { status: "IN_REVIEW" } },
  ]);

  console.log("✅ Tasks, subtasks, comments, and activity logs created");

  // Conversations
  const [dmConv1] = await db
    .insert(conversationsTable)
    .values({
      type: "DIRECT",
      createdById: pm1.id,
    })
    .returning();

  const [dmConv2] = await db
    .insert(conversationsTable)
    .values({
      type: "DIRECT",
      createdById: member1.id,
    })
    .returning();

  const [groupConv] = await db
    .insert(conversationsTable)
    .values({
      type: "GROUP",
      name: "Phoenix Platform Team",
      description: "Main channel for the Phoenix Platform project",
      projectId: activeProject.id,
      createdById: pm1.id,
    })
    .returning();

  if (!dmConv1 || !dmConv2 || !groupConv) {
    throw new Error("Failed to create conversations");
  }

  // Conversation members
  await db.insert(conversationMembersTable).values([
    { conversationId: dmConv1.id, userId: pm1.id, isAdmin: true },
    { conversationId: dmConv1.id, userId: member1.id, isAdmin: false },
    { conversationId: dmConv2.id, userId: member1.id, isAdmin: true },
    { conversationId: dmConv2.id, userId: member2.id, isAdmin: false },
    { conversationId: groupConv.id, userId: pm1.id, isAdmin: true },
    { conversationId: groupConv.id, userId: member1.id, isAdmin: false },
    { conversationId: groupConv.id, userId: member2.id, isAdmin: false },
    { conversationId: groupConv.id, userId: member3.id, isAdmin: false },
    { conversationId: groupConv.id, userId: member4.id, isAdmin: false },
  ]);

  // Messages
  await db.insert(messagesTable).values([
    {
      conversationId: dmConv1.id,
      senderId: pm1.id,
      content: "Hey David, how's the auth service coming along?",
    },
    {
      conversationId: dmConv1.id,
      senderId: member1.id,
      content: "Making good progress! JWT middleware is done, working on refresh tokens now.",
    },
    {
      conversationId: dmConv1.id,
      senderId: pm1.id,
      content: "Great! Let me know if you need any help. Security is our top priority.",
    },
    {
      conversationId: dmConv2.id,
      senderId: member1.id,
      content: "Eva, can you review my PR for the database schema changes?",
    },
    {
      conversationId: dmConv2.id,
      senderId: member2.id,
      content: "Sure! I'll take a look this afternoon. Is there anything specific I should focus on?",
    },
    {
      conversationId: dmConv2.id,
      senderId: member1.id,
      content: "Mainly the indexes and the foreign key constraints. Thanks!",
    },
    {
      conversationId: groupConv.id,
      senderId: pm1.id,
      content: "Team, just a reminder that the Beta Launch milestone is on May 31st. We need to accelerate progress on the dashboard.",
      isPinned: true,
    },
    {
      conversationId: groupConv.id,
      senderId: member3.id,
      content: "On it! The chart components are done, working on the activity feed widget now.",
    },
    {
      conversationId: groupConv.id,
      senderId: member4.id,
      content: "I've completed the performance profiling. Found 3 N+1 queries that need to be fixed.",
    },
    {
      conversationId: groupConv.id,
      senderId: pm1.id,
      content: "Good catch, Grace! Make sure to log those in the task tracker.",
    },
  ]);

  console.log("✅ Conversations and messages created");

  // Notifications
  await db.insert(notificationsTable).values([
    {
      userId: member1.id,
      type: "TASK_ASSIGNED",
      title: "Task Assigned",
      body: `You have been assigned to "${task3.title}"`,
      resourceId: task3.id,
      resourceType: "task",
    },
    {
      userId: member3.id,
      type: "TASK_ASSIGNED",
      title: "Task Assigned",
      body: `You have been assigned to "${task4.title}"`,
      resourceId: task4.id,
      resourceType: "task",
    },
    {
      userId: member1.id,
      type: "TASK_DUE_SOON",
      title: "Task Due Soon",
      body: `"${task3.title}" is due in 2 days`,
      resourceId: task3.id,
      resourceType: "task",
      isRead: false,
    },
    {
      userId: pm1.id,
      type: "TASK_COMPLETED",
      title: "Task Completed",
      body: `"${task1.title}" has been marked as Done`,
      resourceId: task1.id,
      resourceType: "task",
      isRead: true,
    },
    {
      userId: member2.id,
      type: "MENTIONED",
      title: "You were mentioned",
      body: "member1 mentioned you in a comment",
      resourceId: task3.id,
      resourceType: "task",
      isRead: false,
    },
  ]);

  console.log("✅ Notifications created");

  console.log("\n🎉 Database seeded successfully!\n");
  console.log("═══════════════════════════════════════");
  console.log("  DEFAULT LOGIN CREDENTIALS");
  console.log("═══════════════════════════════════════");
  console.log("  Password (all users): Password123!");
  console.log("───────────────────────────────────────");
  console.log(`  Admin:          admin@example.com`);
  console.log(`  Project Mgr 1:  pm1@example.com`);
  console.log(`  Project Mgr 2:  pm2@example.com`);
  console.log(`  Team Member 1:  member1@example.com`);
  console.log(`  Team Member 2:  member2@example.com`);
  console.log(`  Team Member 3:  member3@example.com`);
  console.log(`  Team Member 4:  member4@example.com`);
  console.log(`  Supervisor:     supervisor@example.com`);
  console.log("═══════════════════════════════════════\n");

  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
